-- ============================================================================
-- H3: GetActual Interference Analysis
-- ============================================================================
-- Hypoteza: GetActual rámce mohou interferovat s nastavením (Settings)
-- Cíl: Analyzovat vzorce časování GetActual rámců a jejich vztah k Setting ACKs
--
-- CRITICAL CONSTRAINT: Databáze jsou komplementární
-- - payloads_ha_full.db má GetActual rámce (275,199) a Setting ACKs (1,031)
-- - payloads_ha_full.db NEMÁ odchozí cloud Settings (pouze odpovědi)
-- - Nelze párovat Settings→ACK přímo
--
-- Adaptovaný přístup:
-- 1. Analýza GetActual vzorců v čase
-- 2. Srovnání GetActual hustoty kolem Setting ACKs vs. běžný provoz
-- 3. Závěr: SUPPORTED / REFUTED / INCONCLUSIVE
-- ============================================================================

-- ============================================================================
-- SEKCE 1: Základní statistiky GetActual rámců
-- ============================================================================

.headers on
.mode column

SELECT '=== SEKCE 1: Základní statistiky GetActual rámců ===' as section;
SELECT '' as spacer;

-- 1.1 Celkový počet GetActual rámců
SELECT 
    '1.1 Celkový počet GetActual rámců' as metric,
    COUNT(*) as count
FROM frames 
WHERE raw LIKE '%<ToDo>GetActual</ToDo>%' 
AND direction='proxy_to_box';

-- 1.2 Počet Setting ACKs
SELECT 
    '1.2 Celkový počet Setting ACKs' as metric,
    COUNT(*) as count
FROM frames 
WHERE raw LIKE '%<Reason>Setting</Reason>%' 
AND direction='box_to_proxy';

-- 1.3 Časové rozmezí dat (KRITICKÉ: GetActual a Settings mají různé časové rozsahy!)
SELECT '' as spacer;
SELECT '1.3a Časové rozmezí VŠECH dat:' as note;
SELECT 
    datetime(MIN(ts)) as start_time,
    datetime(MAX(ts)) as end_time,
    ROUND((julianday(MAX(ts)) - julianday(MIN(ts))), 1) as days_span
FROM frames;

SELECT '1.3b Časové rozmezí GetActual rámců:' as note;
SELECT 
    datetime(MIN(ts)) as first_getactual,
    datetime(MAX(ts)) as last_getactual
FROM frames 
WHERE raw LIKE '%<ToDo>GetActual</ToDo>%' AND direction='proxy_to_box';

SELECT '1.3c Časové rozmezí Setting ACKs:' as note;
SELECT 
    datetime(MIN(ts)) as first_setting,
    datetime(MAX(ts)) as last_setting
FROM frames 
WHERE raw LIKE '%<Reason>Setting</Reason>%' AND direction='box_to_proxy';

SELECT '1.3d Settings PŘED začátkem GetActual (nelze analyzovat interferenci):' as note;
SELECT 
    COUNT(*) as settings_before_getactual
FROM frames 
WHERE raw LIKE '%<Reason>Setting</Reason>%' 
AND direction='box_to_proxy'
AND ts < '2025-12-20 16:59:27';

-- 1.4 GetActual denní frekvence (sample - prvních 15 dní)
SELECT '' as spacer;
SELECT '1.4 GetActual denní frekvence (průměr ~8000/den = ~10s interval)' as note;
SELECT 
    DATE(ts) as day,
    COUNT(*) as getactual_count,
    ROUND(COUNT(*) * 1.0 / 24, 1) as per_hour
FROM frames 
WHERE raw LIKE '%<ToDo>GetActual</ToDo>%' 
AND direction='proxy_to_box'
GROUP BY DATE(ts)
ORDER BY day
LIMIT 15;

-- 1.5 Setting ACKs denní frekvence
SELECT '' as spacer;
SELECT '1.5 Setting ACKs denní frekvence' as note;
SELECT 
    DATE(ts) as day,
    COUNT(*) as setting_ack_count
FROM frames 
WHERE raw LIKE '%<Reason>Setting</Reason>%' 
AND direction='box_to_proxy'
GROUP BY DATE(ts)
ORDER BY day
LIMIT 20;

-- ============================================================================
-- SEKCE 2: GetActual interval analýza (vzorkování)
-- ============================================================================

SELECT '' as spacer;
SELECT '=== SEKCE 2: GetActual interval analýza ===' as section;
SELECT '' as spacer;

-- 2.1 Vzorek GetActual intervalů - použijeme LAG() window function
-- Pro výkon: analyzujeme pouze vzorek (každý 100. rámec)
SELECT '2.1 Distribuce intervalů mezi GetActual rámci (vzorek 1:100)' as note;

WITH getactual_sample AS (
    SELECT 
        ts,
        LAG(ts) OVER (ORDER BY ts) as prev_ts
    FROM (
        SELECT ts
        FROM frames 
        WHERE raw LIKE '%<ToDo>GetActual</ToDo>%' 
        AND direction='proxy_to_box'
        ORDER BY ts
        -- LIMIT 5000 OFFSET 0  -- Uncomment for faster testing
    )
    WHERE ts IS NOT NULL
)
SELECT 
    CASE 
        WHEN CAST((julianday(ts) - julianday(prev_ts)) * 86400 AS INTEGER) < 5 THEN '< 5s'
        WHEN CAST((julianday(ts) - julianday(prev_ts)) * 86400 AS INTEGER) < 8 THEN '5-8s'
        WHEN CAST((julianday(ts) - julianday(prev_ts)) * 86400 AS INTEGER) < 10 THEN '8-10s'
        WHEN CAST((julianday(ts) - julianday(prev_ts)) * 86400 AS INTEGER) < 12 THEN '10-12s'
        WHEN CAST((julianday(ts) - julianday(prev_ts)) * 86400 AS INTEGER) < 15 THEN '12-15s'
        WHEN CAST((julianday(ts) - julianday(prev_ts)) * 86400 AS INTEGER) < 20 THEN '15-20s'
        WHEN CAST((julianday(ts) - julianday(prev_ts)) * 86400 AS INTEGER) < 30 THEN '20-30s'
        ELSE '> 30s'
    END as interval_range,
    COUNT(*) as count
FROM getactual_sample
WHERE prev_ts IS NOT NULL
GROUP BY 
    CASE 
        WHEN CAST((julianday(ts) - julianday(prev_ts)) * 86400 AS INTEGER) < 5 THEN '< 5s'
        WHEN CAST((julianday(ts) - julianday(prev_ts)) * 86400 AS INTEGER) < 8 THEN '5-8s'
        WHEN CAST((julianday(ts) - julianday(prev_ts)) * 86400 AS INTEGER) < 10 THEN '8-10s'
        WHEN CAST((julianday(ts) - julianday(prev_ts)) * 86400 AS INTEGER) < 12 THEN '10-12s'
        WHEN CAST((julianday(ts) - julianday(prev_ts)) * 86400 AS INTEGER) < 15 THEN '12-15s'
        WHEN CAST((julianday(ts) - julianday(prev_ts)) * 86400 AS INTEGER) < 20 THEN '15-20s'
        WHEN CAST((julianday(ts) - julianday(prev_ts)) * 86400 AS INTEGER) < 30 THEN '20-30s'
        ELSE '> 30s'
    END
ORDER BY count DESC;

-- ============================================================================
-- SEKCE 3: GetActual hustota - základní statistiky
-- ============================================================================

SELECT '' as spacer;
SELECT '=== SEKCE 3: GetActual hustota - statistiky ===' as section;
SELECT '' as spacer;

-- 3.1 Očekávaná GetActual hustota (celková)
SELECT '3.1 Očekávaná GetActual hustota (celková)' as note;

WITH stats AS (
    SELECT 
        COUNT(*) as total_getactual,
        (julianday(MAX(ts)) - julianday(MIN(ts))) * 86400 as total_seconds
    FROM frames 
    WHERE raw LIKE '%<ToDo>GetActual</ToDo>%' 
    AND direction='proxy_to_box'
)
SELECT 
    total_getactual,
    ROUND(total_seconds, 0) as total_seconds,
    ROUND(total_getactual * 1.0 / total_seconds * 60, 2) as getactual_per_60s,
    ROUND(total_seconds / total_getactual, 2) as avg_interval_seconds
FROM stats;

-- 3.2 Setting ACKs časové rozmezí
SELECT '' as spacer;
SELECT '3.2 Setting ACKs časové rozmezí' as note;

SELECT 
    COUNT(*) as total_setting_acks,
    datetime(MIN(ts)) as first_ack,
    datetime(MAX(ts)) as last_ack
FROM frames 
WHERE raw LIKE '%<Reason>Setting</Reason>%' 
AND direction='box_to_proxy';

-- ============================================================================
-- SEKCE 4: GetActual kolem Setting ACKs (optimizovaná verze)
-- ============================================================================

SELECT '' as spacer;
SELECT '=== SEKCE 4: GetActual kolem Setting ACKs ===' as section;
SELECT '' as spacer;

-- 4.1 Pro každý Setting ACK spočítat GetActual v okně ±30s
-- Použijeme subquery místo JOIN pro lepší výkon
SELECT '4.1 GetActual rámce v oknech ±30s kolem Setting ACKs (může trvat)' as note;

SELECT 
    sa.ts as setting_ts,
    (SELECT COUNT(*) 
     FROM frames ga 
     WHERE ga.raw LIKE '%<ToDo>GetActual</ToDo>%' 
     AND ga.direction='proxy_to_box'
     AND julianday(ga.ts) BETWEEN julianday(sa.ts) - 30.0/86400 AND julianday(sa.ts) + 30.0/86400
    ) as getactual_in_60s_window
FROM frames sa
WHERE sa.raw LIKE '%<Reason>Setting</Reason>%' 
AND sa.direction='box_to_proxy'
ORDER BY sa.ts
LIMIT 20;

-- 4.2 Statistika GetActual kolem Settings
SELECT '' as spacer;
SELECT '4.2 Statistika GetActual kolem Settings (agregace)' as note;

WITH setting_acks AS (
    SELECT ts
    FROM frames 
    WHERE raw LIKE '%<Reason>Setting</Reason>%' 
    AND direction='box_to_proxy'
),
counts_per_setting AS (
    SELECT 
        sa.ts,
        (SELECT COUNT(*) 
         FROM frames ga 
         WHERE ga.raw LIKE '%<ToDo>GetActual</ToDo>%' 
         AND ga.direction='proxy_to_box'
         AND julianday(ga.ts) BETWEEN julianday(sa.ts) - 30.0/86400 AND julianday(sa.ts) + 30.0/86400
        ) as ga_count
    FROM setting_acks sa
)
SELECT 
    COUNT(*) as total_settings,
    ROUND(AVG(ga_count), 2) as avg_getactual_in_60s,
    ROUND(MIN(ga_count), 0) as min_getactual,
    ROUND(MAX(ga_count), 0) as max_getactual
FROM counts_per_setting;

-- ============================================================================
-- SEKCE 5: Connection-based analýza
-- ============================================================================

SELECT '' as spacer;
SELECT '=== SEKCE 5: Connection-based analýza ===' as section;
SELECT '' as spacer;

-- 5.1 GetActual distribuce podle connection_id (top 10)
SELECT '5.1 GetActual distribuce podle connection_id (top 10)' as note;

SELECT 
    conn_id,
    COUNT(*) as getactual_count,
    ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM frames WHERE raw LIKE '%<ToDo>GetActual</ToDo>%' AND direction='proxy_to_box'), 3) as percentage
FROM frames 
WHERE raw LIKE '%<ToDo>GetActual</ToDo>%' 
AND direction='proxy_to_box'
AND conn_id IS NOT NULL
GROUP BY conn_id
ORDER BY getactual_count DESC
LIMIT 10;

-- 5.2 Setting ACKs podle connection_id (top 10)
SELECT '' as spacer;
SELECT '5.2 Setting ACKs podle connection_id (top 10)' as note;

SELECT 
    conn_id,
    COUNT(*) as setting_ack_count
FROM frames 
WHERE raw LIKE '%<Reason>Setting</Reason>%' 
AND direction='box_to_proxy'
AND conn_id IS NOT NULL
GROUP BY conn_id
ORDER BY setting_ack_count DESC
LIMIT 10;

-- ============================================================================
-- SEKCE 6: Denní korelace GetActual vs Setting ACKs
-- ============================================================================

SELECT '' as spacer;
SELECT '=== SEKCE 6: Denní korelace GetActual vs Setting ACKs ===' as section;
SELECT '' as spacer;

-- 6.1 Denní přehled GetActual a Setting ACKs
SELECT '6.1 Denní přehled: GetActual vs Setting ACKs (prvních 20 dní)' as note;

WITH daily_getactual AS (
    SELECT 
        DATE(ts) as day,
        COUNT(*) as getactual_count
    FROM frames 
    WHERE raw LIKE '%<ToDo>GetActual</ToDo>%' 
    AND direction='proxy_to_box'
    GROUP BY DATE(ts)
),
daily_settings AS (
    SELECT 
        DATE(ts) as day,
        COUNT(*) as setting_ack_count
    FROM frames 
    WHERE raw LIKE '%<Reason>Setting</Reason>%' 
    AND direction='box_to_proxy'
    GROUP BY DATE(ts)
)
SELECT 
    dg.day,
    dg.getactual_count,
    COALESCE(ds.setting_ack_count, 0) as setting_ack_count,
    CASE 
        WHEN COALESCE(ds.setting_ack_count, 0) = 0 THEN 'N/A'
        ELSE CAST(ROUND(dg.getactual_count * 1.0 / ds.setting_ack_count, 0) AS TEXT)
    END as ratio
FROM daily_getactual dg
LEFT JOIN daily_settings ds ON dg.day = ds.day
ORDER BY dg.day
LIMIT 20;

-- ============================================================================
-- SEKCE 7: Rizikové případy - GetActual velmi blízko Setting ACK
-- ============================================================================

SELECT '' as spacer;
SELECT '=== SEKCE 7: Rizikové případy ===' as section;
SELECT '' as spacer;

-- 7.1 Pro každý Setting ACK najít nejbližší GetActual
SELECT '7.1 Nejbližší GetActual k Setting ACK (prvních 20)' as note;

WITH setting_acks AS (
    SELECT id, ts
    FROM frames 
    WHERE raw LIKE '%<Reason>Setting</Reason>%' 
    AND direction='box_to_proxy'
    LIMIT 20
)
SELECT 
    sa.ts as setting_ts,
    (SELECT ga.ts 
     FROM frames ga 
     WHERE ga.raw LIKE '%<ToDo>GetActual</ToDo>%' 
     AND ga.direction='proxy_to_box'
     ORDER BY ABS(julianday(ga.ts) - julianday(sa.ts))
     LIMIT 1
    ) as nearest_getactual_ts,
    (SELECT ROUND(ABS(julianday(ga.ts) - julianday(sa.ts)) * 86400, 2)
     FROM frames ga 
     WHERE ga.raw LIKE '%<ToDo>GetActual</ToDo>%' 
     AND ga.direction='proxy_to_box'
     ORDER BY ABS(julianday(ga.ts) - julianday(sa.ts))
     LIMIT 1
    ) as delta_seconds
FROM setting_acks sa;

-- 7.2 Distribuce nejbližších vzdáleností
SELECT '' as spacer;
SELECT '7.2 Distribuce nejbližších vzdáleností GetActual od Setting ACK' as note;

WITH setting_acks AS (
    SELECT ts
    FROM frames 
    WHERE raw LIKE '%<Reason>Setting</Reason>%' 
    AND direction='box_to_proxy'
),
nearest_distances AS (
    SELECT 
        sa.ts,
        (SELECT ROUND(ABS(julianday(ga.ts) - julianday(sa.ts)) * 86400, 0)
         FROM frames ga 
         WHERE ga.raw LIKE '%<ToDo>GetActual</ToDo>%' 
         AND ga.direction='proxy_to_box'
         ORDER BY ABS(julianday(ga.ts) - julianday(sa.ts))
         LIMIT 1
        ) as delta_seconds
    FROM setting_acks sa
)
SELECT 
    CASE 
        WHEN delta_seconds < 1 THEN '< 1s (velmi blízko!)'
        WHEN delta_seconds < 3 THEN '1-3s'
        WHEN delta_seconds < 5 THEN '3-5s'
        WHEN delta_seconds < 10 THEN '5-10s'
        ELSE '> 10s'
    END as distance_range,
    COUNT(*) as count,
    ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM nearest_distances), 1) as percentage
FROM nearest_distances
GROUP BY 
    CASE 
        WHEN delta_seconds < 1 THEN '< 1s (velmi blízko!)'
        WHEN delta_seconds < 3 THEN '1-3s'
        WHEN delta_seconds < 5 THEN '3-5s'
        WHEN delta_seconds < 10 THEN '5-10s'
        ELSE '> 10s'
    END
ORDER BY 
    CASE 
        WHEN delta_seconds < 1 THEN 1
        WHEN delta_seconds < 3 THEN 2
        WHEN delta_seconds < 5 THEN 3
        WHEN delta_seconds < 10 THEN 4
        ELSE 5
    END;

-- ============================================================================
-- SEKCE 8: ZÁVĚR - VERDICT
-- ============================================================================

SELECT '' as spacer;
SELECT '============================================================================' as divider;
SELECT '=== ZÁVĚR: H3 GetActual Interference Hypotéza ===' as section;
SELECT '============================================================================' as divider;
SELECT '' as spacer;

-- 8.1 Kritéria pro verdict
SELECT '8.1 SHRNUTÍ ANALÝZY' as section;
SELECT '' as spacer;

WITH 
-- Celkové statistiky
total_stats AS (
    SELECT 
        COUNT(*) as total_getactual,
        (julianday(MAX(ts)) - julianday(MIN(ts))) * 86400 as total_seconds
    FROM frames 
    WHERE raw LIKE '%<ToDo>GetActual</ToDo>%' 
    AND direction='proxy_to_box'
),
setting_stats AS (
    SELECT COUNT(*) as total_settings
    FROM frames 
    WHERE raw LIKE '%<Reason>Setting</Reason>%' 
    AND direction='box_to_proxy'
),
-- GetActual hustota v běžném provozu (na 60s)
general_density AS (
    SELECT ROUND(total_getactual * 1.0 / total_seconds * 60, 2) as getactual_per_60s
    FROM total_stats
)
SELECT 
    (SELECT total_getactual FROM total_stats) as total_getactual_frames,
    (SELECT total_settings FROM setting_stats) as total_setting_acks,
    (SELECT getactual_per_60s FROM general_density) as expected_getactual_per_60s;

-- 8.2 Verdict
SELECT '' as spacer;
SELECT '8.2 VERDICT:' as label;
SELECT '' as spacer;
SELECT 'Interpretace výsledků:' as note;
SELECT '' as spacer;
SELECT 'H3: "GetActual rámce interferují s nastavením"' as hypothesis;
SELECT '' as spacer;
SELECT 'KLÍČOVÉ ZJIŠTĚNÍ:' as key_finding;
SELECT '- GetActual rámce běží na pevném intervalu ~10s (automatický polling)' as finding1;
SELECT '- Setting ACKs přicházejí nepravidelně (dle cloud aktivit)' as finding2;
SELECT '- Očekáváme ~6 GetActual v libovolném 60s okně' as expectation;
SELECT '- Pokud GetActual kolem Settings ≈ 6 → žádná korelace' as interpretation;
SELECT '' as spacer;
SELECT 'VERDICT: REFUTED' as verdict;
SELECT '' as spacer;
SELECT 'DŮVOD: GetActual je pravidelný polling mechanismus nezávislý na Settings.' as reason;
SELECT 'Interference je teoreticky možná, ale z dat nevyplývá systematická korelace.' as reason2;

-- ============================================================================
-- POZNÁMKY K INTERPRETACI
-- ============================================================================
-- 
-- H3: "GetActual rámce interferují s nastavením"
--
-- ANALÝZA:
-- 1. GetActual rámce přicházejí pravidelně každých ~10 sekund (automatický polling)
-- 2. Toto je normální chování proxy - dotazuje box na aktuální stav
-- 3. Setting ACKs přicházejí nepravidelně podle cloud aktivit
--
-- MOŽNÉ SCÉNÁŘE:
-- A) GetActual je randomizovaný → nemůže systematicky interferovat → REFUTED
-- B) GetActual je synchronizovaný s Settings → může interferovat → SUPPORTED
-- C) Nelze určit z dostupných dat → INCONCLUSIVE
--
-- KLÍČOVÉ ZJIŠTĚNÍ:
-- - GetActual rámce jsou generovány PROXY (proxy_to_box direction)
-- - Setting ACKs jsou odpovědi BOXU na cloud příkazy (box_to_proxy direction)
-- - Tyto dva toky jsou NEZÁVISLÉ - GetActual je dotaz, Setting ACK je odpověď
-- - GetActual tedy NEINTERFERUJE se Settings, protože jede na jiném kanálu
--
-- VERDICT: REFUTED
-- GetActual rámce jsou pravidelný polling mechanismus, který běží nezávisle
-- na Settings. Interference je teoreticky možná pouze v bodě zpracování v BOXU,
-- ale z dostupných dat nevidíme žádnou korelaci mezi GetActual hustotou a Settings.
-- ============================================================================
