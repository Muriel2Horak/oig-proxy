-- SQL skript pro vytvoření časové mapy všech Setting-related událostí
-- Vytváří kompletní timeline s matched Setting→ACK→tbl_events sekvencemi
-- Identifikuje ghost ACKs a orphan Settings

-- =====================================================================
-- DATABÁZE: ANALÝZA PAYLOADS.DB (11.-12. PROSINCE 2025)
-- =====================================================================

-- Vytvoření připojení k payloads.db (pro analýzu dat z 11.-12.12.2025)
ATTACH DATABASE '/tmp/payloads_test.db' AS db1;

-- =====================================================================
-- 1. EXTRAKCE CLOUD SETTINGS (proxy_to_cloud s tbl_*_prms)
--    Toto jsou nastavení odesílaná z proxy do cloudu
-- =====================================================================

CREATE TABLE IF NOT EXISTS cloud_settings_db1 AS
SELECT 
    id,
    ts as timestamp,
    'db1' as database_name,
    'cloud_setting' as event_type,
    direction,
    device_id,
    SUBSTR(parsed, 1, 100) as parsed_preview,
    length
FROM db1.frames 
WHERE direction = 'proxy_to_cloud' 
  AND parsed LIKE '%tbl_%prms%'
  AND parsed NOT LIKE '%tbl_events%'
  AND ts NOT LIKE '2026-02-16%'  -- Vyloučení 16.2.2026 dat
ORDER BY ts;

-- =====================================================================
-- 2. EXTRAKCE BOX SETTING ACKS (box_to_proxy s Type=Setting)
--    Toto jsou potvrzení nastavení z boxu
-- =====================================================================

CREATE TABLE IF NOT EXISTS box_setting_acks_db1 AS
SELECT 
    id,
    ts as timestamp,
    'db1' as database_name,
    'setting_ack' as event_type,
    direction,
    device_id,
    json_extract(parsed, '$._dt') as event_dt,
    json_extract(parsed, '$.Type') as event_type_detail,
    json_extract(parsed, '$.Confirm') as confirm_status,
    json_extract(parsed, '$.Content') as content,
    length
FROM db1.frames 
WHERE direction = 'box_to_proxy' 
  AND parsed LIKE '%Type":"Setting"%'
  AND ts NOT LIKE '2026-02-16%'  -- Vyloučení 16.2.2026 dat
ORDER BY ts;

-- =====================================================================
-- 3. EXTRAKCE TBL_EVENTS (box_to_proxy s tbl_events)
--    Všechny tbl_events události pro kompletní přehled
-- =====================================================================

CREATE TABLE IF NOT EXISTS tbl_events_db1 AS
SELECT 
    id,
    ts as timestamp,
    'db1' as database_name,
    'tbl_event' as event_type,
    direction,
    device_id,
    json_extract(parsed, '$._dt') as event_dt,
    json_extract(parsed, '$.Type') as event_type_detail,
    json_extract(parsed, '$.Confirm') as confirm_status,
    json_extract(parsed, '$.Content') as content,
    length
FROM db1.frames 
WHERE parsed LIKE '%_table":"tbl_events"%'
  AND ts NOT LIKE '2026-02-16%'  -- Vyloučení 16.2.2026 dat
ORDER BY ts;

-- =====================================================================
-- 4. EXTRAKCE ISNEWSET FRAMES (box_to_proxy s Result=IsNewSet)
--    Toto jsou telemetrická data IsNewSet
-- =====================================================================

CREATE TABLE IF NOT EXISTS isnewset_frames_db1 AS
SELECT 
    id,
    ts as timestamp,
    'db1' as database_name,
    'isnewset' as event_type,
    direction,
    device_id,
    json_extract(parsed, '$.Result') as result,
    json_extract(parsed, '$.Lat') as latency,
    length
FROM db1.frames 
WHERE direction = 'box_to_proxy' 
  AND parsed LIKE '%Result":"IsNewSet"%'
  AND ts NOT LIKE '2026-02-16%'  -- Vyloučení 16.2.2026 dat
ORDER BY ts;

-- =====================================================================
-- DATABÁZE: ANALÝZA PAYLOADS_HA_FULL.DB (18. PROSINCE 2025 - 1. ÚNORA 2026)
-- =====================================================================

-- Vytvoření připojení k payloads_ha_full.db
ATTACH DATABASE '/tmp/payloads_ha_full_test.db' AS db2;

-- =====================================================================
-- 5. EXTRAKCE CLOUD SETTINGS z payloads_ha_full.db
-- =====================================================================

CREATE TABLE IF NOT EXISTS cloud_settings_db2 AS
SELECT 
    id,
    ts as timestamp,
    'db2' as database_name,
    'cloud_setting' as event_type,
    direction,
    device_id,
    SUBSTR(parsed, 1, 100) as parsed_preview,
    length
FROM db2.frames 
WHERE direction = 'proxy_to_cloud' 
  AND parsed LIKE '%tbl_%prms%'
  AND parsed NOT LIKE '%tbl_events%'
  AND ts NOT LIKE '2026-02-16%'  -- Vyloučení 16.2.2026 dat
ORDER BY ts;

-- =====================================================================
-- 6. EXTRAKCE BOX SETTING ACKS z payloads_ha_full.db
-- =====================================================================

CREATE TABLE IF NOT EXISTS box_setting_acks_db2 AS
SELECT 
    id,
    ts as timestamp,
    'db2' as database_name,
    'setting_ack' as event_type,
    direction,
    device_id,
    json_extract(parsed, '$._dt') as event_dt,
    json_extract(parsed, '$.Type') as event_type_detail,
    json_extract(parsed, '$.Confirm') as confirm_status,
    json_extract(parsed, '$.Content') as content,
    length
FROM db2.frames 
WHERE direction = 'box_to_proxy' 
  AND parsed LIKE '%Type":"Setting"%'
  AND ts NOT LIKE '2026-02-16%'  -- Vyloučení 16.2.2026 dat
ORDER BY ts;

-- =====================================================================
-- 7. EXTRAKCE TBL_EVENTS z payloads_ha_full.db
-- =====================================================================

CREATE TABLE IF NOT EXISTS tbl_events_db2 AS
SELECT 
    id,
    ts as timestamp,
    'db2' as database_name,
    'tbl_event' as event_type,
    direction,
    device_id,
    json_extract(parsed, '$._dt') as event_dt,
    json_extract(parsed, '$.Type') as event_type_detail,
    json_extract(parsed, '$.Confirm') as confirm_status,
    json_extract(parsed, '$.Content') as content,
    length
FROM db2.frames 
WHERE parsed LIKE '%_table":"tbl_events"%'
  AND ts NOT LIKE '2026-02-16%'  -- Vyloučení 16.2.2026 dat
ORDER BY ts;

-- =====================================================================
-- 8. EXTRAKCE ISNEWSET FRAMES z payloads_ha_full.db
-- =====================================================================

CREATE TABLE IF NOT EXISTS isnewset_frames_db2 AS
SELECT 
    id,
    ts as timestamp,
    'db2' as database_name,
    'isnewset' as event_type,
    direction,
    device_id,
    json_extract(parsed, '$.Result') as result,
    json_extract(parsed, '$.Lat') as latency,
    length
FROM db2.frames 
WHERE direction = 'box_to_proxy' 
  AND parsed LIKE '%Result":"IsNewSet"%'
  AND ts NOT LIKE '2026-02-16%'  -- Vyloučení 16.2.2026 dat
ORDER BY ts;

-- =====================================================================
-- 9. SPOJENÍ VŠECH DAT DO JEDNÉ TABULKY
-- =====================================================================

CREATE TABLE IF NOT EXISTS all_setting_events AS
SELECT * FROM cloud_settings_db1
UNION ALL
SELECT * FROM box_setting_acks_db1
UNION ALL
SELECT * FROM tbl_events_db1
UNION ALL
SELECT * FROM isnewset_frames_db1
UNION ALL
SELECT * FROM cloud_settings_db2
UNION ALL
SELECT * FROM box_setting_acks_db2
UNION ALL
SELECT * FROM tbl_events_db2
UNION ALL
SELECT * FROM isnewset_frames_db2
ORDER BY database_name, timestamp;

-- =====================================================================
-- 10. MATCHOVÁNÍ SETTINGS → ACKS (±30 sekundové okno)
--     Hledání spárovaných nastavení s jejich potvrzeními
-- =====================================================================

CREATE TABLE IF NOT EXISTS matched_setting_ack_pairs AS
WITH 
-- Cloud settings z obou databází
all_cloud_settings AS (
    SELECT * FROM cloud_settings_db1
    UNION ALL
    SELECT * FROM cloud_settings_db2
),
-- Box ACKs z obou databází
all_box_acks AS (
    SELECT * FROM box_setting_acks_db1
    UNION ALL
    SELECT * FROM box_setting_acks_db2
),
-- Pairing pomocí časového okna ±30 sekund
setting_ack_pairs AS (
    SELECT 
        cs.id as cloud_setting_id,
        cs.timestamp as cloud_setting_time,
        cs.database_name as cloud_setting_db,
        ba.id as box_ack_id,
        ba.timestamp as box_ack_time,
        ba.database_name as box_ack_db,
        CAST(strftime('%s', ba.timestamp) AS INTEGER) - CAST(strftime('%s', cs.timestamp) AS INTEGER) as delta_seconds,
        CASE 
            WHEN ABS(CAST(strftime('%s', ba.timestamp) AS INTEGER) - CAST(strftime('%s', cs.timestamp) AS INTEGER)) <= 30 THEN 'matched'
            ELSE 'out_of_window'
        END as match_status
    FROM all_cloud_settings cs
    LEFT JOIN all_box_acks ba ON 
        ABS(CAST(strftime('%s', ba.timestamp) AS INTEGER) - CAST(strftime('%s', cs.timestamp) AS INTEGER)) <= 30
        AND ba.device_id = cs.device_id
)
SELECT * FROM setting_ack_pairs
WHERE match_status = 'matched'
ORDER BY cloud_setting_time;

-- =====================================================================
-- 11. IDENTIFIKACE GHOST ACKS (ACKs bez odpovídajícího Setting v ±30s)
--     "Duchovní" potvrzení, která nemají původní nastavení
-- =====================================================================

CREATE TABLE IF NOT EXISTS ghost_acks AS
WITH 
-- Cloud settings z obou databází
all_cloud_settings AS (
    SELECT * FROM cloud_settings_db1
    UNION ALL
    SELECT * FROM cloud_settings_db2
),
-- Box ACKs z obou databází
all_box_acks AS (
    SELECT * FROM box_setting_acks_db1
    UNION ALL
    SELECT * FROM box_setting_acks_db2
),
-- Všechny možné páry
all_possible_pairs AS (
    SELECT 
        ba.id as box_ack_id,
        ba.timestamp as box_ack_time,
        ba.database_name as box_ack_db,
        ba.content,
        cs.id as cloud_setting_id,
        cs.timestamp as cloud_setting_time,
        cs.database_name as cloud_setting_db,
        ABS(CAST(strftime('%s', ba.timestamp) AS INTEGER) - CAST(strftime('%s', cs.timestamp) AS INTEGER)) as time_diff
    FROM all_box_acks ba
    LEFT JOIN all_cloud_settings cs ON 
        ABS(CAST(strftime('%s', ba.timestamp) AS INTEGER) - CAST(strftime('%s', cs.timestamp) AS INTEGER)) <= 30
        AND ba.device_id = cs.device_id
)
SELECT 
    box_ack_id,
    box_ack_time,
    box_ack_db,
    content,
    'GHOST_ACK' as ghost_type
FROM all_possible_pairs
WHERE cloud_setting_id IS NULL
ORDER BY box_ack_time;

-- =====================================================================
-- 12. IDENTIFIKACE ORPHAN SETTINGS (Settings bez odpovídajícího ACK v ±30s)
--     "Sirotčí" nastavení, která nikdy nedostala potvrzení
-- =====================================================================

CREATE TABLE IF NOT EXISTS orphan_settings AS
WITH 
-- Cloud settings z obou databází
all_cloud_settings AS (
    SELECT * FROM cloud_settings_db1
    UNION ALL
    SELECT * FROM cloud_settings_db2
),
-- Box ACKs z obou databází
all_box_acks AS (
    SELECT * FROM box_setting_acks_db1
    UNION ALL
    SELECT * FROM box_setting_acks_db2
),
-- Všechny možné páry
all_possible_pairs AS (
    SELECT 
        cs.id as cloud_setting_id,
        cs.timestamp as cloud_setting_time,
        cs.database_name as cloud_setting_db,
        ba.id as box_ack_id,
        ba.timestamp as box_ack_time,
        ba.database_name as box_ack_db,
        ABS(CAST(strftime('%s', ba.timestamp) AS INTEGER) - CAST(strftime('%s', cs.timestamp) AS INTEGER)) as time_diff
    FROM all_cloud_settings cs
    LEFT JOIN all_box_acks ba ON 
        ABS(CAST(strftime('%s', ba.timestamp) AS INTEGER) - CAST(strftime('%s', cs.timestamp) AS INTEGER)) <= 30
        AND ba.device_id = cs.device_id
)
SELECT 
    cloud_setting_id,
    cloud_setting_time,
    cloud_setting_db,
    parsed_preview,
    'ORPHAN_SETTING' as orphan_type
FROM all_possible_pairs
WHERE box_ack_id IS NULL
ORDER BY cloud_setting_time;

-- =====================================================================
-- 13. DENNÍ SOUHRNY UDÁLOSTÍ PODLE DATABASE
--     Počet událostí podle dnů pro každou databázi
-- =====================================================================

CREATE TABLE IF NOT EXISTS daily_event_counts AS
WITH 
-- Počty událostí pro db1 (payloads.db)
db1_counts AS (
    SELECT 
        'db1' as database_name,
        DATE(timestamp) as event_date,
        COUNT(CASE WHEN event_type = 'cloud_setting' THEN 1 END) as cloud_settings_count,
        COUNT(CASE WHEN event_type = 'setting_ack' THEN 1 END) as setting_acks_count,
        COUNT(CASE WHEN event_type = 'tbl_event' AND event_type_detail = 'Setting' THEN 1 END) as tbl_events_setting_count,
        COUNT(CASE WHEN event_type = 'isnewset' THEN 1 END) as isnewset_count
    FROM all_setting_events
    WHERE database_name = 'db1'
    GROUP BY DATE(timestamp)
),
-- Počty událostí pro db2 (payloads_ha_full.db)
db2_counts AS (
    SELECT 
        'db2' as database_name,
        DATE(timestamp) as event_date,
        COUNT(CASE WHEN event_type = 'cloud_setting' THEN 1 END) as cloud_settings_count,
        COUNT(CASE WHEN event_type = 'setting_ack' THEN 1 END) as setting_acks_count,
        COUNT(CASE WHEN event_type = 'tbl_event' AND event_type_detail = 'Setting' THEN 1 END) as tbl_events_setting_count,
        COUNT(CASE WHEN event_type = 'isnewset' THEN 1 END) as isnewset_count
    FROM all_setting_events
    WHERE database_name = 'db2'
    GROUP BY DATE(timestamp)
)
SELECT * FROM db1_counts
UNION ALL
SELECT * FROM db2_counts
ORDER BY database_name, event_date;

-- =====================================================================
-- 14. STATISTIKY DELTA ČASŮ PRO MATCHED PÁRY
--     Analýza doby odpovědi mezi nastavením a potvrzením
-- =====================================================================

CREATE TABLE IF NOT EXISTS delta_time_statistics AS
SELECT 
    COUNT(*) as total_matched_pairs,
    AVG(delta_seconds) as avg_delta_seconds,
    MIN(delta_seconds) as min_delta_seconds,
    MAX(delta_seconds) as max_delta_seconds,
    AVG(delta_seconds) / 60.0 as avg_delta_minutes,
    database_name as cloud_setting_db
FROM matched_setting_ack_pairs
GROUP BY cloud_setting_db;

-- =====================================================================
-- 15. ANALÝZA GHOST ACKS - DENNÍ SESTUPY
--     Které dny mají nejvíce duchovních potvrzení
-- =====================================================================

CREATE TABLE IF NOT EXISTS ghost_acks_daily_analysis AS
SELECT 
    DATE(box_ack_time) as ghost_ack_date,
    COUNT(*) as ghost_ack_count,
    database_name as source_database
FROM ghost_acks
GROUP BY DATE(box_ack_time), database_name
ORDER BY ghost_ack_date, source_database;

-- =====================================================================
-- 16. VÝSTUPNÍ REPORTY
-- =====================================================================

-- 16.1 Souhrnné statistiky
.print '=== SOUHRNNÉ STATISTIKY ==='
SELECT 'TOTAL EVENTS' as metric, COUNT(*) as count FROM all_setting_events
UNION ALL
SELECT 'CLOUD SETTINGS', COUNT(*) FROM cloud_settings_db1
UNION ALL  
SELECT 'CLOUD SETTINGS (HA)', COUNT(*) FROM cloud_settings_db2
UNION ALL
SELECT 'SETTING ACKS', COUNT(*) FROM box_setting_acks_db1
UNION ALL
SELECT 'SETTING ACKS (HA)', COUNT(*) FROM box_setting_acks_db2
UNION ALL
SELECT 'TBL EVENTS (Setting)', COUNT(*) FROM tbl_events_db1 WHERE event_type_detail = 'Setting'
UNION ALL
SELECT 'TBL EVENTS (Setting, HA)', COUNT(*) FROM tbl_events_db2 WHERE event_type_detail = 'Setting'
UNION ALL
SELECT 'ISNEWSET FRAMES', COUNT(*) FROM isnewset_frames_db1
UNION ALL
SELECT 'ISNEWSET FRAMES (HA)', COUNT(*) FROM isnewset_frames_db2
UNION ALL
SELECT 'MATCHED PAIRS', COUNT(*) FROM matched_setting_ack_pairs
UNION ALL
SELECT 'GHOST ACKS', COUNT(*) FROM ghost_acks
UNION ALL
SELECT 'ORPHAN SETTINGS', COUNT(*) FROM orphan_settings;

-- 16.2 Ukázky ghost ACKs
.print ''
.print '=== PŘÍKLADY GHOST ACKS (prvních 10) ==='
SELECT box_ack_time, box_ack_db, SUBSTR(content, 1, 100) as content_preview 
FROM ghost_acks 
LIMIT 10;

-- 16.3 Ukázky orphan settings
.print ''
.print '=== PŘÍKLADY ORPHAN SETTINGS (prvních 10) ==='
SELECT cloud_setting_time, cloud_setting_db, SUBSTR(parsed_preview, 1, 100) as setting_preview 
FROM orphan_settings 
LIMIT 10;

-- 16.4 Statistiky delta časů
.print ''
.print '=== STATISTIKY DOBY ODPOVĚDI ==='
SELECT * FROM delta_time_statistics;

-- 16.5 Analýza ghost ACKs podle dnů
.print ''
.print '=== GHOST ACKS PODLE DNŮ ==='
SELECT * FROM ghost_acks_daily_analysis ORDER BY ghost_ack_count DESC;

-- 16.6 Kontrola známého případu: 23. ledna 2026
.print ''
.print '=== KONTROLA: 23. LEDNA 2026 (očekáváno 7 ghost ACKs) ==='
SELECT 
    COUNT(*) as jan_23_ghost_acks,
    database_name
FROM ghost_acks 
WHERE DATE(box_ack_time) = '2026-01-23'
GROUP BY database_name;

-- 16.7 Kontrola posledního cloud setting: 4. ledna 2026
.print ''
.print '=== KONTROLA: POSLEDNÍ CLOUD SETTING (očekáváno 4.1.2026 17:37:40) ==='
SELECT 
    timestamp,
    database_name,
    parsed_preview
FROM (
    SELECT * FROM cloud_settings_db2
    UNION ALL
    SELECT * FROM cloud_settings_db1
)
WHERE timestamp LIKE '2026-01-04%'
ORDER BY timestamp DESC
LIMIT 5;

-- =====================================================================
-- 17. ČISTÍCÍ OPERACE (volitelné)
-- =====================================================================

-- Pro odstranění dočasných tabulek odkomentujte následující řádky:
/*
DROP TABLE IF EXISTS cloud_settings_db1;
DROP TABLE IF EXISTS box_setting_acks_db1;
DROP TABLE IF EXISTS tbl_events_db1;
DROP TABLE IF EXISTS isnewset_frames_db1;
DROP TABLE IF EXISTS cloud_settings_db2;
DROP TABLE IF EXISTS box_setting_acks_db2;
DROP TABLE IF EXISTS tbl_events_db2;
DROP TABLE IF EXISTS isnewset_frames_db2;
DROP TABLE IF EXISTS all_setting_events;
DROP TABLE IF EXISTS matched_setting_ack_pairs;
DROP TABLE IF EXISTS ghost_acks;
DROP TABLE IF EXISTS orphan_settings;
DROP TABLE IF EXISTS daily_event_counts;
DROP TABLE IF EXISTS delta_time_statistics;
DROP TABLE IF EXISTS ghost_acks_daily_analysis;
*/

.print ''
.print '=== ANALÝZA DOKONČENA ==='
.print 'Vytvořeny tabulky: matched_setting_ack_pairs, ghost_acks, orphan_settings, daily_event_counts, delta_time_statistics, ghost_acks_daily_analysis'