-- SQL skript pro vytvoření časové mapy všech Setting-related událostí
-- Verze bez ATTACH DATABASE - pracuje přímo s jednou databází
-- Spouštějte: sqlite3 /cesta/k/databazi.db < timeline_simplified.sql

-- =====================================================================
-- VYTVOŘENÍ TEMPORARY TABLES PRO ANALÝZU
-- =====================================================================

-- 1. Cloud Settings (proxy_to_cloud s tbl_*_prms)
CREATE TEMP TABLE IF NOT EXISTS cloud_settings AS
SELECT 
    id,
    ts as timestamp,
    'current_db' as database_name,
    'cloud_setting' as event_type,
    direction,
    device_id,
    SUBSTR(parsed, 1, 100) as parsed_preview,
    length
FROM frames 
WHERE direction = 'proxy_to_cloud' 
  AND parsed LIKE '%tbl_%prms%'
  AND parsed NOT LIKE '%tbl_events%'
  AND ts NOT LIKE '2026-02-16%'  -- Vyloučení 16.2.2026 dat
ORDER BY ts;

-- 2. Box Setting ACKs (box_to_proxy s Type=Setting)
CREATE TEMP TABLE IF NOT EXISTS box_setting_acks AS
SELECT 
    id,
    ts as timestamp,
    'current_db' as database_name,
    'setting_ack' as event_type,
    direction,
    device_id,
    json_extract(parsed, '$._dt') as event_dt,
    json_extract(parsed, '$.Type') as event_type_detail,
    json_extract(parsed, '$.Confirm') as confirm_status,
    json_extract(parsed, '$.Content') as content,
    length
FROM frames 
WHERE direction = 'box_to_proxy' 
  AND parsed LIKE '%Type":"Setting"%'
  AND ts NOT LIKE '2026-02-16%'  -- Vyloučení 16.2.2026 dat
ORDER BY ts;

-- 3. Tbl_events (box_to_proxy s tbl_events)
CREATE TEMP TABLE IF NOT EXISTS tbl_events AS
SELECT 
    id,
    ts as timestamp,
    'current_db' as database_name,
    'tbl_event' as event_type,
    direction,
    device_id,
    json_extract(parsed, '$._dt') as event_dt,
    json_extract(parsed, '$.Type') as event_type_detail,
    json_extract(parsed, '$.Confirm') as confirm_status,
    json_extract(parsed, '$.Content') as content,
    length
FROM frames 
WHERE parsed LIKE '%_table":"tbl_events"%'
  AND ts NOT LIKE '2026-02-16%'  -- Vyloučení 16.2.2026 dat
ORDER BY ts;

-- 4. IsNewSet frames (box_to_proxy s Result=IsNewSet)
CREATE TEMP TABLE IF NOT EXISTS isnewset_frames AS
SELECT 
    id,
    ts as timestamp,
    'current_db' as database_name,
    'isnewset' as event_type,
    direction,
    device_id,
    json_extract(parsed, '$.Result') as result,
    json_extract(parsed, '$.Lat') as latency,
    length
FROM frames 
WHERE direction = 'box_to_proxy' 
  AND parsed LIKE '%Result":"IsNewSet"%'
  AND ts NOT LIKE '2026-02-16%'  -- Vyloučení 16.2.2026 dat
ORDER BY ts;

-- =====================================================================
-- VÝSTUPNÍ ANALÝZY
-- =====================================================================

SELECT '=== ANALÝZA PRO VERZI: ' || sqlite_version() || ' ===' as info;

-- 1. Základní statistiky
SELECT '=== ZÁKLADNÍ STATISTIKY ===' as section;
SELECT 
    'CLOUD SETTINGS' as event_type,
    COUNT(*) as count
FROM cloud_settings
UNION ALL
SELECT 
    'SETTING ACKS',
    COUNT(*)
FROM box_setting_acks
UNION ALL
SELECT 
    'TBL_EVENTS (Setting)',
    COUNT(*)
FROM tbl_events
WHERE event_type_detail = 'Setting'
UNION ALL
SELECT 
    'ISNEWSET FRAMES',
    COUNT(*)
FROM isnewset_frames;

-- 2. Matched Setting→ACK pairs (±30s)
PRINT '';
PRINT '=== MATCHED SETTING→ACK PAIRS (±30s) ===';
CREATE TEMP TABLE IF NOT EXISTS matched_pairs AS
SELECT 
    cs.id as cloud_setting_id,
    cs.timestamp as cloud_setting_time,
    ba.id as box_ack_id,
    ba.timestamp as box_ack_time,
    CAST(strftime('%s', ba.timestamp) AS INTEGER) - CAST(strftime('%s', cs.timestamp) AS INTEGER) as delta_seconds,
    CASE 
        WHEN ABS(CAST(strftime('%s', ba.timestamp) AS INTEGER) - CAST(strftime('%s', cs.timestamp) AS INTEGER)) <= 30 THEN 'matched'
        ELSE 'out_of_window'
    END as match_status
FROM cloud_settings cs
LEFT JOIN box_setting_acks ba ON 
    ABS(CAST(strftime('%s', ba.timestamp) AS INTEGER) - CAST(strftime('%s', cs.timestamp) AS INTEGER)) <= 30
    AND ba.device_id = cs.device_id
WHERE ABS(CAST(strftime('%s', ba.timestamp) AS INTEGER) - CAST(strftime('%s', cs.timestamp) AS INTEGER)) <= 30;

SELECT 
    COUNT(*) as matched_pairs_count,
    AVG(delta_seconds) as avg_delta_seconds,
    MIN(delta_seconds) as min_delta_seconds,
    MAX(delta_seconds) as max_delta_seconds
FROM matched_pairs;

-- 3. Ghost ACKs (ACKs bez odpovídajícího Setting)
PRINT '';
PRINT '=== GHOST ACKS (ACKs bez odpovídajícího Setting v ±30s) ===';
CREATE TEMP TABLE IF NOT EXISTS ghost_acks AS
SELECT 
    ba.id as box_ack_id,
    ba.timestamp as box_ack_time,
    ba.content,
    'GHOST_ACK' as ghost_type
FROM box_setting_acks ba
WHERE NOT EXISTS (
    SELECT 1 FROM cloud_settings cs
    WHERE ABS(CAST(strftime('%s', ba.timestamp) AS INTEGER) - CAST(strftime('%s', cs.timestamp) AS INTEGER)) <= 30
      AND ba.device_id = cs.device_id
);

SELECT 
    COUNT(*) as ghost_acks_count,
    MIN(timestamp) as first_ghost_ack,
    MAX(timestamp) as last_ghost_ack
FROM ghost_acks;

-- 4. Orphan Settings (Settings bez odpovídajícího ACK)
PRINT '';
PRINT '=== ORPHAN SETTINGS (Settings bez odpovídajícího ACK v ±30s) ===';
CREATE TEMP TABLE IF NOT EXISTS orphan_settings AS
SELECT 
    cs.id as cloud_setting_id,
    cs.timestamp as cloud_setting_time,
    cs.parsed_preview,
    'ORPHAN_SETTING' as orphan_type
FROM cloud_settings cs
WHERE NOT EXISTS (
    SELECT 1 FROM box_setting_acks ba
    WHERE ABS(CAST(strftime('%s', ba.timestamp) AS INTEGER) - CAST(strftime('%s', cs.timestamp) AS INTEGER)) <= 30
      AND ba.device_id = cs.device_id
);

SELECT 
    COUNT(*) as orphan_settings_count,
    MIN(timestamp) as first_orphan_setting,
    MAX(timestamp) as last_orphan_setting
FROM orphan_settings;

-- 5. Denní souhrny událostí
PRINT '';
PRINT '=== DENNÍ SOUHRNY UDÁLOSTÍ ===';
CREATE TEMP TABLE IF NOT EXISTS daily_counts AS
SELECT 
    DATE(timestamp) as event_date,
    COUNT(CASE WHEN event_type = 'cloud_setting' THEN 1 END) as cloud_settings_count,
    COUNT(CASE WHEN event_type = 'setting_ack' THEN 1 END) as setting_acks_count,
    COUNT(CASE WHEN event_type = 'tbl_event' AND event_type_detail = 'Setting' THEN 1 END) as tbl_events_setting_count,
    COUNT(CASE WHEN event_type = 'isnewset' THEN 1 END) as isnewset_count
FROM (
    SELECT * FROM cloud_settings
    UNION ALL
    SELECT * FROM box_setting_acks
    UNION ALL
    SELECT * FROM tbl_events
    UNION ALL
    SELECT * FROM isnewset_frames
)
GROUP BY DATE(timestamp)
ORDER BY event_date;

SELECT * FROM daily_counts;

-- 6. Ghost ACKs analýza podle dnů
PRINT '';
PRINT '=== GHOST ACKS PODLE DNŮ ===';
CREATE TEMP TABLE IF NOT EXISTS ghost_acks_daily AS
SELECT 
    DATE(timestamp) as ghost_ack_date,
    COUNT(*) as ghost_ack_count
FROM ghost_acks
GROUP BY DATE(timestamp)
ORDER BY ghost_ack_date;

SELECT * FROM ghost_acks_daily;

-- 7. Příklady ghost ACKs
PRINT '';
PRINT '=== PŘÍKLADY GHOST ACKS (prvních 5) ===';
SELECT 
    timestamp,
    SUBSTR(content, 1, 100) as content_preview
FROM ghost_acks
LIMIT 5;

-- 8. Příklady orphan settings
PRINT '';
PRINT '=== PŘÍKLADY ORPHAN SETTINGS (prvních 5) ===';
SELECT 
    timestamp,
    SUBSTR(parsed_preview, 1, 100) as setting_preview
FROM orphan_settings
LIMIT 5;

-- 9. Kontrola specifických dat
PRINT '';
PRINT '=== KONTROLA: 23. LEDNA 2026 (očekáváno 7 ghost ACKs) ===';
SELECT 
    COUNT(*) as jan_23_ghost_acks
FROM ghost_acks 
WHERE DATE(timestamp) = '2026-01-23';

PRINT '';
PRINT '=== KONTROLA: POSLEDNÍ CLOUD SETTING (očekáváno 4.1.2026 17:37:40) ===';
SELECT 
    timestamp,
    parsed_preview
FROM cloud_settings
WHERE timestamp LIKE '2026-01-04%'
ORDER BY timestamp DESC
LIMIT 3;

PRINT '';
PRINT '=== ANALÝZA DOKONČENA ===';

-- Čištění temporary tables
DROP TABLE IF EXISTS cloud_settings;
DROP TABLE IF EXISTS box_setting_acks;
DROP TABLE IF EXISTS tbl_events;
DROP TABLE IF EXISTS isnewset_frames;
DROP TABLE IF EXISTS matched_pairs;
DROP TABLE IF EXISTS ghost_acks;
DROP TABLE IF EXISTS orphan_settings;
DROP TABLE IF EXISTS daily_counts;
DROP TABLE IF EXISTS ghost_acks_daily;