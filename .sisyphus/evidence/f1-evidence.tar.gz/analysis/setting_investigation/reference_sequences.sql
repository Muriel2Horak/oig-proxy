-- ============================================================================
-- reference_sequences.sql
-- Kompletní sekvence funkčního Setting delivery
-- 
-- KRITICKÉ OMEZENÍ: Databáze jsou komplementární, ne překrývající se:
-- - payloads.db (Dec 11-12, 2025): Má odchozí Settings (209), ale ŽÁDNÉ Setting ACKs
-- - payloads_ha_full.db (Dec 18, 2025 - Jan 23, 2026): Má Setting ACKs (767), ale ŽÁDNÉ odchozí Settings
-- 
-- Kompletní párované sekvence (Setting→ACK) jsou NEMOŽNÉ s aktuálními daty!
-- ============================================================================

-- ============================================================================
-- SEKCE 1: payloads.db - ODCHOZÍ SETTINGS (Dec 11-12, 2025)
-- ============================================================================

-- 1.1 Celkový počet Settings a časový rozsah
SELECT '=== 1.1 SETTINGS V payloads.db ===' as section;
SELECT 
    COUNT(*) as total_settings,
    MIN(ts) as first_setting,
    MAX(ts) as last_setting
FROM frames 
WHERE direction='proxy_to_cloud' 
AND table_name LIKE 'tbl_%_prms';

-- 1.2 Settings seskupené podle tabulky
SELECT '=== 1.2 SETTINGS PODLE TABULKY ===' as section;
SELECT 
    table_name,
    COUNT(*) as count,
    ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM frames WHERE direction='proxy_to_cloud' AND table_name LIKE 'tbl_%_prms'), 1) as percentage
FROM frames 
WHERE direction='proxy_to_cloud' 
AND table_name LIKE 'tbl_%_prms'
GROUP BY table_name
ORDER BY count DESC;

-- 1.3 Settings seskupené podle dne a hodiny
SELECT '=== 1.3 ČASOVÁ DISTRIBUCE SETTINGS ===' as section;
SELECT 
    date(ts) as day,
    strftime('%H', ts) as hour,
    COUNT(*) as settings_count
FROM frames 
WHERE direction='proxy_to_cloud' 
AND table_name LIKE 'tbl_%_prms'
GROUP BY day, hour
ORDER BY day, hour;

-- 1.4 Prvních 5 Settings s detaily
SELECT '=== 1.4 PRVNÍCH 5 SETTINGS ===' as section;
SELECT 
    id,
    datetime(ts) as timestamp,
    direction,
    table_name,
    length,
    substr(parsed, 1, 200) as parsed_preview
FROM frames 
WHERE direction='proxy_to_cloud' 
AND table_name LIKE 'tbl_%_prms'
ORDER BY ts
LIMIT 5;

-- 1.5 Reprezentativní Setting s okolními rámmi (±60s)
-- Setting id=966 (tbl_box_prms, Dec 11 18:06:10 UTC)
SELECT '=== 1.5 SEKVENCE KOLEM SETTING id=966 (tbl_box_prms) ===' as section;
SELECT 
    id,
    datetime(ts) as timestamp,
    direction,
    table_name,
    length,
    CASE 
        WHEN direction='proxy_to_cloud' AND table_name LIKE 'tbl_%_prms' THEN '>>> SETTING'
        WHEN direction='cloud_to_proxy' AND length <= 80 THEN '<<< CLOUD ACK'
        WHEN direction='box_to_proxy' AND table_name LIKE 'tbl_%_prms' THEN '>>> BOX DATA'
        ELSE ''
    END as frame_role
FROM frames 
WHERE ts BETWEEN '2025-12-11T18:05:00' AND '2025-12-11T18:07:30'
ORDER BY ts;

-- 1.6 Kontrola Setting ACKs (tbl_events s Type="Setting") v payloads.db
SELECT '=== 1.6 SETTING ACKs V payloads.db (očekáváno: 0) ===' as section;
SELECT COUNT(*) as setting_acks_count
FROM frames 
WHERE table_name='tbl_events' 
AND parsed LIKE '%"Type": "Setting"%'
AND direction='box_to_proxy';

-- 1.7 Kontrola GetActual v payloads.db
SELECT '=== 1.7 GetActual V payloads.db ===' as section;
SELECT COUNT(*) as getactual_count
FROM frames 
WHERE table_name='GetActual';

-- ============================================================================
-- SEKCE 2: payloads_ha_full.db - SETTING ACKs (Dec 18, 2025 - Jan 23, 2026)
-- ============================================================================

-- 2.1 Celkový počet Setting ACKs a časový rozsah
SELECT '=== 2.1 SETTING ACKs V payloads_ha_full.db ===' as section;
SELECT 
    COUNT(*) as total_acks,
    MIN(ts) as first_ack,
    MAX(ts) as last_ack
FROM frames 
WHERE table_name='tbl_events' 
AND parsed LIKE '%"Type": "Setting"%'
AND direction='box_to_proxy';

-- 2.2 Setting ACKs seskupené podle dne
SELECT '=== 2.2 SETTING ACKs PODLE DNE ===' as section;
SELECT 
    date(ts) as day,
    COUNT(*) as ack_count
FROM frames 
WHERE table_name='tbl_events' 
AND parsed LIKE '%"Type": "Setting"%'
AND direction='box_to_proxy'
GROUP BY day
ORDER BY day;

-- 2.3 Kontrola odchozích Settings v payloads_ha_full.db
SELECT '=== 2.3 SETTINGS V payloads_ha_full.db (očekáváno: 0) ===' as section;
SELECT COUNT(*) as settings_count
FROM frames 
WHERE direction='proxy_to_cloud' 
AND table_name LIKE 'tbl_%_prms';

-- 2.4 Reprezentativní Setting ACK s detaily
-- ACK id=263 (první Setting ACK, Dec 18 19:26:59)
SELECT '=== 2.4 DETAIL SETTING ACK id=263 ===' as section;
SELECT 
    id,
    datetime(ts) as timestamp,
    direction,
    table_name,
    conn_id,
    length,
    parsed
FROM frames 
WHERE id = 263;

-- 2.5 Rámy kolem ACK id=263 na stejné conn_id (±60s)
SELECT '=== 2.5 SEKVENCE KOLEM ACK id=263 (conn_id=2, ±60s) ===' as section;
SELECT 
    id,
    datetime(ts) as timestamp,
    direction,
    table_name,
    length,
    CASE 
        WHEN table_name='tbl_events' AND parsed LIKE '%"Type": "Setting"%' THEN '>>> SETTING ACK'
        WHEN direction='cloud_to_proxy' AND length <= 60 THEN '<<< CLOUD ACK'
        WHEN table_name LIKE 'tbl_%_prms' THEN '>>> PARAM DATA'
        ELSE ''
    END as frame_role
FROM frames 
WHERE conn_id = 2
AND ts BETWEEN '2025-12-18T19:25:59' AND '2025-12-18T19:27:59'
ORDER BY ts;

-- 2.6 GetActual v payloads_ha_full.db
SELECT '=== 2.6 GetActual V payloads_ha_full.db ===' as section;
SELECT COUNT(*) as getactual_count
FROM frames 
WHERE table_name='GetActual';

-- 2.7 IsNewSet v payloads_ha_full.db
SELECT '=== 2.7 IsNewSet V payloads_ha_full.db ===' as section;
SELECT COUNT(*) as isnewset_count
FROM frames 
WHERE table_name='IsNewSet';

-- ============================================================================
-- SEKCE 3: KRITICKÉ ZJIŠTĚNÍ - DATABÁZE JSOU KOMPLEMENTÁRNÍ
-- ============================================================================

SELECT '=== 3.1 KRITICKÉ ZJIŠTĚNÍ ===' as section;
SELECT 'Databáze jsou KOMPLEMENTÁRNÍ, ne překrývající se:' as finding;
SELECT '- payloads.db: Má Settings (209) ale ŽÁDNÉ ACKs' as db1_summary;
SELECT '- payloads_ha_full.db: Má ACKs (767) ale ŽÁDNÉ Settings' as db2_summary;
SELECT 'Kompletní párované sekvence (Setting→ACK) jsou NEMOŽNÉ!' as conclusion;

-- 3.2 Časová mezera mezi posledním Setting a prvním ACK
SELECT '=== 3.2 ČASOVÁ MEZERA ===' as section;
SELECT 
    'Poslední Setting v payloads.db: 2025-12-12 18:37:34 UTC' as last_setting,
    'První ACK v payloads_ha_full.db: 2025-12-18 19:26:59 UTC' as first_ack,
    'Mezera: ~6 dní' as gap;

-- ============================================================================
-- SEKCE 4: PROTOKOLOVÁ SEKVENCE (co můžeme vidět)
-- ============================================================================

-- 4.1 V payloads.db můžeme vidět protokolovou sekvenci:
-- box_to_proxy -> proxy_to_cloud -> cloud_to_proxy -> proxy_to_box
SELECT '=== 4.1 PROTOKOLOVÁ SEKVENCE V payloads.db ===' as section;
SELECT 'Setting flow: box_to_proxy -> proxy_to_cloud -> cloud_to_proxy(75B ACK) -> proxy_to_box' as protocol;

-- 4.2 V payloads_ha_full.db vidíme:
-- box_to_proxy (tbl_events Setting ACK) -> cloud_to_proxy (53B ACK)
SELECT '=== 4.2 PROTOKOLOVÁ SEKVENCE V payloads_ha_full.db ===' as section;
SELECT 'ACK flow: box_to_proxy(tbl_events) -> cloud_to_proxy(53B ACK)' as protocol;
