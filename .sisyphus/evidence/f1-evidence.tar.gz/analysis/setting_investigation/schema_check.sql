-- SQL skript pro ověření schémat a datový inventář
-- Tento skript validuje kompatibilitu schémat mezi oběma databázemi a reportuje inventář dat
-- Poznámka: Tento skript je navržen pro spuštění z adresáře projektu s připojenými databázemi

-- Spuštění: sqlite3 analysis/ha_snapshot/payloads.db < analysis/setting_investigation/schema_check.sql
-- nebo: sqlite3 analysis/ha_snapshot/payloads_ha_full.db < analysis/setting_investigation/schema_check.sql

-- =====================================================================
-- 1. Kontrola schémat tabulky 'frames' v obou databázích
-- =====================================================================

-- Schéma tabulky 'frames' v payloads.db (December 11-12, 2025)
-- Spusťte tento dotaz v databázi payloads.db:
-- PRAGMA table_info(frames);

-- Schéma tabulky 'frames' v payloads_ha_full.db (December 18, 2025 - February 1, 2026)  
-- Spusťte tento dotaz v databázi payloads_ha_full.db:
-- PRAGMA table_info(frames);

-- =====================================================================
-- 2. Celkový počet záznamů v každé databázi
-- =====================================================================

-- Celkový počet framů v aktuální databázi
SELECT 
    'Current DB' as source,
    COUNT(*) as total_frames 
FROM sqlite_master 
WHERE type='table' AND name='frames';

-- Pro porovnání s druhou databází spusťte stejný dotaz v ní
-- Očekávané výsledky:
-- - payloads.db: ~52,107 framů
-- - payloads_ha_full.db: ~871,952 framů

-- =====================================================================
-- 3. Časové rozmezí pro každou databázi
-- =====================================================================

-- Časové rozmezí v aktuální databázi
SELECT 
    MIN(ts) as earliest_timestamp,
    MAX(ts) as latest_timestamp,
    COUNT(*) as total_frames,
    JULIANDAY(MAX(ts)) - JULIANDAY(MIN(ts)) as days_span
FROM frames;

-- =====================================================================
-- 4. Ověření absence dat z 16. února 2026 (mock-server data)
-- =====================================================================

-- Kontrola dat z 16. února 2026 v aktuální databázi
SELECT 
    COUNT(*) as feb_16_2026_count,
    'POUŽITO PRO TESTOVÁNÍ - TATO DATA MUSÍ BÝT VYŘAZENA' as warning
FROM frames 
WHERE ts LIKE '2026-02-16%';

-- =====================================================================
-- 5. Počet framů podle směru pro každou databázi
-- =====================================================================

-- Počet framů podle směru v aktuální databázi
SELECT 
    direction,
    COUNT(*) as frame_count,
    ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM frames), 2) as percentage
FROM frames 
WHERE direction IS NOT NULL
GROUP BY direction
ORDER BY frame_count DESC;

-- =====================================================================
-- 6. Top 10 nejčastějších názvů tabulek pro každou databázi
-- =====================================================================

-- Top 10 tabulek v aktuální databázi
SELECT 
    table_name,
    COUNT(*) as frequency,
    ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM frames), 2) as percentage
FROM frames 
WHERE table_name IS NOT NULL
GROUP BY table_name
ORDER BY frequency DESC
LIMIT 10;

-- =====================================================================
-- 7. Analýza conn_id - počet unikátních spojení
-- =====================================================================

-- Analýza conn_id v aktuální databázi
SELECT 
    COUNT(DISTINCT conn_id) as unique_connections,
    COUNT(*) as total_frames
FROM frames;

-- =====================================================================
-- 8. Kontrola existence raw_b64 sloupce (klíčový rozdíl mezi schématy)
-- =====================================================================

-- Kontrola raw_b64 sloupce v aktuální databázi
-- Poznámka: Tento dotaz selže, pokud sloupec raw_b64 neexistuje (což je očekáváno pro payloads.db)
SELECT 
    COUNT(*) as raw_b64_records
FROM frames 
WHERE raw_b64 IS NOT NULL;

-- =====================================================================
-- 9. Shrnutí klíčových rozdílů mezi schématy
-- =====================================================================

-- Toto je manuální kontrola - spusťte PRAGMA table_info(frames) v obou databázích
-- a porovnejte výsledky:
--
-- payloads.db má sloupce: id, ts, device_id, table_name, raw, parsed, direction, conn_id, peer, length
-- payloads_ha_full.db má navíc: raw_b64
-- 
-- Hlavní rozdíly:
-- 1. payloads_ha_full.db má navíc sloupec raw_b64
-- 2. payloads.db má většinou conn_id = NULL
-- 3. payloads_ha_full.db má naplněné conn_id (přibližně 18,334 unikátních hodnot)

-- Kontrola raw_b64 sloupce v payloads_ha_full.db
-- POZNÁMKA: Tento dotaz spusťte pouze v databázi payloads_ha_full.db
-- SELECT 
--     'payloads_ha_full.db' as database_name,
--     COUNT(*) as raw_b64_records,
--     'Tato databáze by měla mít raw_b64 sloupec s daty' as note
-- FROM frames 
-- WHERE raw_b64 IS NOT NULL;