-- ============================================================================
-- H2+H4: IsNewSet format change + Protocol state before Settings
-- ============================================================================
-- Účel: Analyzovat změnu formátu IsNewSet (H2) a protokolový stav před Settings (H4)
-- 
-- H2 - IsNewSet format change:
--   - Verifikovat distribuci délek IsNewSet v obou databázích
--   - Hledat přechod z SHORT (121-124B) na LONG (760B) formát
--   - Extrahovat verze firmwaru z IsNewFW rámců
--
-- H4 - Protocol state before Settings:
--   - Analýza 5 rámců před každým Setting v payloads.db
--   - Analýza 5 rámců před každým Setting ACK v payloads_ha_full.db
--   - Hledání vzorců v protokolové sekvenci
--   - Timing analýza
--
-- Použití:
--   sqlite3 /path/to/payloads.db < h2_h4_isnewset_protocol.sql
--   sqlite3 /path/to/payloads_ha_full.db < h2_h4_isnewset_protocol.sql
--
-- ============================================================================

-- ============================================================================
-- DETEKCE TYPU DATABÁZE
-- ============================================================================
-- Detekce: payloads.db nemá raw_b64, payloads_ha_full.db má raw_b64

.headers on
.mode column

SELECT '========================================' AS '';
SELECT 'H2+H4: IsNewSet Format + Protocol State' AS '';
SELECT '========================================' AS '';
SELECT '' AS '';

-- Detekce typu databáze
SELECT 'DETEKCE DATABÁZE:' AS '';
SELECT 
    CASE 
        WHEN (SELECT COUNT(*) FROM pragma_table_info('frames') WHERE name='raw_b64') > 0 
        THEN 'payloads_ha_full.db (s raw_b64, conn_id)'
        ELSE 'payloads.db (bez raw_b64)'
    END AS 'Typ databáze';

SELECT '' AS '';

-- ============================================================================
-- H2.1: DISTRIBUCE DÉLEK IsNewSet
-- ============================================================================

SELECT '==========' AS '';
SELECT 'H2.1: IsNewSet DÉLKY - DISTRIBUCE' AS '';
SELECT '==========' AS '';
SELECT '' AS '';

-- Počet IsNewSet rámců a distribuce délek
SELECT 
    'IsNewSet rámce' AS 'Analýza',
    COUNT(*) AS 'Počet',
    MIN(length) AS 'Min délka',
    MAX(length) AS 'Max délka',
    AVG(length) AS 'Prům. délka'
FROM frames 
WHERE (raw LIKE '%Result>IsNewSet%' OR parsed LIKE '%"Result": "IsNewSet"%')
  AND direction = 'box_to_proxy';

SELECT '' AS '';

-- Distribuce délek IsNewSet
SELECT 
    length AS 'Délka (B)',
    COUNT(*) AS 'Počet',
    ROUND(100.0 * COUNT(*) / (SELECT COUNT(*) FROM frames 
                               WHERE (raw LIKE '%Result>IsNewSet%' OR parsed LIKE '%"Result": "IsNewSet"%')
                                 AND direction = 'box_to_proxy'), 2) AS 'Procento'
FROM frames 
WHERE (raw LIKE '%Result>IsNewSet%' OR parsed LIKE '%"Result": "IsNewSet"%')
  AND direction = 'box_to_proxy'
GROUP BY length
ORDER BY length;

SELECT '' AS '';

-- Klasifikace SHORT vs LONG
SELECT 
    CASE 
        WHEN length <= 150 THEN 'SHORT (<=150B)'
        WHEN length >= 700 THEN 'LONG (>=700B)'
        ELSE 'STŘEDNÍ (150-700B)'
    END AS 'Kategorie',
    COUNT(*) AS 'Počet',
    ROUND(100.0 * COUNT(*) / NULLIF((SELECT COUNT(*) FROM frames 
                               WHERE (raw LIKE '%Result>IsNewSet%' OR parsed LIKE '%"Result": "IsNewSet"%')
                                 AND direction = 'box_to_proxy'), 0), 2) AS 'Procento',
    MIN(length) AS 'Min délka',
    MAX(length) AS 'Max délka'
FROM frames 
WHERE (raw LIKE '%Result>IsNewSet%' OR parsed LIKE '%"Result": "IsNewSet"%')
  AND direction = 'box_to_proxy'
GROUP BY CASE 
        WHEN length <= 150 THEN 'SHORT (<=150B)'
        WHEN length >= 700 THEN 'LONG (>=700B)'
        ELSE 'STŘEDNÍ (150-700B)'
    END
ORDER BY MIN(length);

SELECT '' AS '';

-- ============================================================================
-- H2.2: HLEDÁNÍ PŘECHODU FORMÁTU (SHORT -> LONG)
-- ============================================================================

SELECT '==========' AS '';
SELECT 'H2.2: PŘECHOD FORMÁTU IsNewSet' AS '';
SELECT '==========' AS '';
SELECT '' AS '';

-- Denní distribuce délek IsNewSet (pro detekci přechodu)
SELECT 
    DATE(ts) AS 'Datum',
    COUNT(*) AS 'IsNewSet počet',
    MIN(length) AS 'Min délka',
    MAX(length) AS 'Max délka',
    ROUND(AVG(length), 1) AS 'Prům. délka',
    SUM(CASE WHEN length <= 150 THEN 1 ELSE 0 END) AS 'SHORT (<=150B)',
    SUM(CASE WHEN length >= 700 THEN 1 ELSE 0 END) AS 'LONG (>=700B)'
FROM frames 
WHERE (raw LIKE '%Result>IsNewSet%' OR parsed LIKE '%"Result": "IsNewSet"%')
  AND direction = 'box_to_proxy'
GROUP BY DATE(ts)
ORDER BY DATE(ts);

SELECT '' AS '';

-- Detailní seznam LONG IsNewSet rámců (pokud existují)
SELECT 'LONG IsNewSet rámce (>=700B):' AS '';
SELECT 
    id,
    ts AS 'Timestamp',
    length AS 'Délka',
    device_id,
    SUBSTR(raw, 1, 200) AS 'Začátek raw'
FROM frames 
WHERE (raw LIKE '%Result>IsNewSet%' OR parsed LIKE '%"Result": "IsNewSet"%')
  AND direction = 'box_to_proxy'
  AND length >= 700
ORDER BY ts
LIMIT 20;

SELECT '' AS '';

-- ============================================================================
-- H2.3: VERZE FIRMWARU (z IsNewFW rámců)
-- ============================================================================

SELECT '==========' AS '';
SELECT 'H2.3: VERZE FIRMWARU (IsNewFW)' AS '';
SELECT '==========' AS '';
SELECT '' AS '';

-- Počet IsNewFW rámců
SELECT 
    'IsNewFW rámce' AS 'Analýza',
    COUNT(*) AS 'Počet'
FROM frames 
WHERE raw LIKE '%Result>IsNewFW%' OR parsed LIKE '%"Result": "IsNewFW"%';

SELECT '' AS '';

-- Extrakce verze firmwaru z raw obsahu
-- Formát: <Fw>v.4.25.43.1219</Fw>
SELECT 
    DATE(ts) AS 'Datum',
    COUNT(*) AS 'Počet',
    -- Extrakce verze z XML tagu <Fw>
    CASE 
        WHEN raw LIKE '%<Fw>%v.%</Fw>%' THEN
            SUBSTR(
                raw,
                INSTR(raw, '<Fw>') + 4,
                INSTR(raw, '</Fw>') - INSTR(raw, '<Fw>') - 4
            )
        ELSE 'N/A'
    END AS 'Verze FW',
    SUBSTR(raw, 1, 300) AS 'Ukázka raw'
FROM frames 
WHERE raw LIKE '%Result>IsNewFW%' OR parsed LIKE '%"Result": "IsNewFW"%'
GROUP BY DATE(ts), 
    CASE 
        WHEN raw LIKE '%<Fw>%v.%</Fw>%' THEN
            SUBSTR(
                raw,
                INSTR(raw, '<Fw>') + 4,
                INSTR(raw, '</Fw>') - INSTR(raw, '<Fw>') - 4
            )
        ELSE 'N/A'
    END
ORDER BY DATE(ts);

SELECT '' AS '';

-- ============================================================================
-- H4.1: PROTOKOLOVÝ STAV PŘED SETTINGS (payloads.db)
-- ============================================================================

SELECT '==========' AS '';
SELECT 'H4.1: STAV PŘED SETTINGS (payloads.db)' AS '';
SELECT '==========' AS '';
SELECT '' AS '';

-- Počet odchozích Settings
SELECT 
    'Odchozí Settings (proxy_to_cloud)' AS 'Analýza',
    COUNT(*) AS 'Počet'
FROM frames 
WHERE direction = 'proxy_to_cloud' 
  AND (raw LIKE '%tbl_%_prms%' OR parsed LIKE '%tbl_%_prms%');

SELECT '' AS '';

-- Pro payloads.db: najít 5 rámců před každým Setting
-- (bez conn_id používáme časovou blízkost na stejném device_id)
WITH settings AS (
    SELECT id, ts, device_id
    FROM frames 
    WHERE direction = 'proxy_to_cloud' 
      AND (raw LIKE '%tbl_%_prms%' OR parsed LIKE '%tbl_%_prms%')
    ORDER BY ts
    LIMIT 50  -- Omezíme na prvních 50 pro přehlednost
),
frames_before AS (
    SELECT 
        s.id AS setting_id,
        s.ts AS setting_ts,
        f.id AS frame_id,
        f.ts AS frame_ts,
        f.direction,
        f.table_name,
        f.length,
        CASE 
            WHEN f.raw LIKE '%Result>IsNewSet%' OR f.parsed LIKE '%"Result": "IsNewSet"%' THEN 'IsNewSet'
            WHEN f.raw LIKE '%Result>IsNewFW%' OR f.parsed LIKE '%"Result": "IsNewFW"%' THEN 'IsNewFW'
            WHEN f.raw LIKE '%GetActual%' OR f.parsed LIKE '%GetActual%' THEN 'GetActual'
            WHEN f.raw LIKE '%ACK%' OR f.parsed LIKE '%ACK%' THEN 'ACK'
            WHEN f.table_name LIKE '%tbl_%_prms%' THEN 'tbl_*_prms'
            WHEN f.table_name = 'tbl_events' THEN 'tbl_events'
            WHEN f.table_name = 'tbl_actual' THEN 'tbl_actual'
            ELSE COALESCE(f.table_name, 'other')
        END AS frame_type,
        ROW_NUMBER() OVER (PARTITION BY s.id ORDER BY f.ts DESC) AS rn
    FROM settings s
    JOIN frames f ON f.device_id = s.device_id 
                  AND f.ts < s.ts 
                  AND f.ts >= DATETIME(s.ts, '-60 seconds')  -- Rámce do 60s před Setting
)
SELECT 
    DATE(setting_ts) AS 'Datum',
    TIME(setting_ts) AS 'Čas Setting',
    frame_type AS 'Typ rámce',
    direction AS 'Směr',
    COUNT(*) AS 'Počet',
    ROUND(AVG(STRFTIME('%s', setting_ts) - STRFTIME('%s', frame_ts)), 2) AS 'Prům. delta (s)'
FROM frames_before
WHERE rn <= 5
GROUP BY DATE(setting_ts), TIME(setting_ts), frame_type, direction
ORDER BY setting_ts, frame_type
LIMIT 100;

SELECT '' AS '';

-- Přehled nejčastějších typů rámců před Setting
SELECT 'Nejčastější rámce před Setting (všechny Settings):' AS '';
SELECT 
    frame_type AS 'Typ rámce',
    direction AS 'Směr',
    COUNT(*) AS 'Počet výskytů',
    ROUND(AVG(delta_s), 2) AS 'Prům. čas před Setting (s)',
    MIN(delta_s) AS 'Min delta (s)',
    MAX(delta_s) AS 'Max delta (s)'
FROM (
    SELECT 
        s.id AS setting_id,
        f.id AS frame_id,
        CASE 
            WHEN f.raw LIKE '%Result>IsNewSet%' OR f.parsed LIKE '%"Result": "IsNewSet"%' THEN 'IsNewSet'
            WHEN f.raw LIKE '%Result>IsNewFW%' OR f.parsed LIKE '%"Result": "IsNewFW"%' THEN 'IsNewFW'
            WHEN f.raw LIKE '%GetActual%' OR f.parsed LIKE '%GetActual%' THEN 'GetActual'
            WHEN f.raw LIKE '%ACK%' OR f.parsed LIKE '%ACK%' THEN 'ACK'
            WHEN f.table_name LIKE '%tbl_%_prms%' THEN 'tbl_*_prms'
            WHEN f.table_name = 'tbl_events' THEN 'tbl_events'
            WHEN f.table_name = 'tbl_actual' THEN 'tbl_actual'
            ELSE COALESCE(f.table_name, 'other')
        END AS frame_type,
        f.direction,
        STRFTIME('%s', s.ts) - STRFTIME('%s', f.ts) AS delta_s,
        ROW_NUMBER() OVER (PARTITION BY s.id ORDER BY f.ts DESC) AS rn
    FROM frames s
    JOIN frames f ON f.device_id = s.device_id 
                  AND f.ts < s.ts 
                  AND f.ts >= DATETIME(s.ts, '-60 seconds')
    WHERE s.direction = 'proxy_to_cloud' 
      AND (s.raw LIKE '%tbl_%_prms%' OR s.parsed LIKE '%tbl_%_prms%')
)
WHERE rn <= 5
GROUP BY frame_type, direction
ORDER BY COUNT(*) DESC;

SELECT '' AS '';

-- ============================================================================
-- H4.2: PROTOKOLOVÝ STAV PŘED SETTING ACK (payloads_ha_full.db)
-- ============================================================================

SELECT '==========' AS '';
SELECT 'H4.2: STAV PŘED SETTING ACK (payloads_ha_full.db)' AS '';
SELECT '==========' AS '';
SELECT '' AS '';

-- Počet Setting ACK z BOXu
SELECT 
    'Setting ACK (box_to_proxy, tbl_events Type=Setting)' AS 'Analýza',
    COUNT(*) AS 'Počet'
FROM frames 
WHERE direction = 'box_to_proxy' 
  AND table_name = 'tbl_events'
  AND (raw LIKE '%Type>Setting%' OR parsed LIKE '%"Type": "Setting"%');

SELECT '' AS '';

-- Pro payloads_ha_full.db: najít 5 rámců před každým Setting ACK
-- Používáme conn_id pro přesnější párování
WITH setting_acks AS (
    SELECT id, ts, device_id, conn_id
    FROM frames 
    WHERE direction = 'box_to_proxy' 
      AND table_name = 'tbl_events'
      AND (raw LIKE '%Type>Setting%' OR parsed LIKE '%"Type": "Setting"%')
    ORDER BY ts
    LIMIT 100  -- Omezíme pro přehlednost
),
frames_before_ack AS (
    SELECT 
        a.id AS ack_id,
        a.ts AS ack_ts,
        a.conn_id,
        f.id AS frame_id,
        f.ts AS frame_ts,
        f.direction,
        f.table_name,
        f.length,
        CASE 
            WHEN f.raw LIKE '%Result>IsNewSet%' OR f.parsed LIKE '%"Result": "IsNewSet"%' THEN 'IsNewSet'
            WHEN f.raw LIKE '%Result>IsNewFW%' OR f.parsed LIKE '%"Result": "IsNewFW"%' THEN 'IsNewFW'
            WHEN f.raw LIKE '%GetActual%' OR f.parsed LIKE '%GetActual%' THEN 'GetActual'
            WHEN f.raw LIKE '%ACK%' OR f.parsed LIKE '%ACK%' THEN 'ACK'
            WHEN f.table_name LIKE '%tbl_%_prms%' THEN 'tbl_*_prms (Setting z cloudu)'
            WHEN f.table_name = 'tbl_events' THEN 'tbl_events'
            WHEN f.table_name = 'tbl_actual' THEN 'tbl_actual'
            ELSE COALESCE(f.table_name, 'other')
        END AS frame_type,
        ROW_NUMBER() OVER (PARTITION BY a.id ORDER BY f.ts DESC) AS rn
    FROM setting_acks a
    JOIN frames f ON (f.conn_id = a.conn_id OR (f.conn_id IS NULL AND f.device_id = a.device_id))
                  AND f.ts < a.ts 
                  AND f.ts >= DATETIME(a.ts, '-60 seconds')  -- Rámce do 60s před ACK
)
SELECT 
    DATE(ack_ts) AS 'Datum',
    ack_id AS 'ACK ID',
    conn_id AS 'Conn ID',
    GROUP_CONCAT(frame_type, ' -> ') AS 'Sekvence rámců (5 před ACK)',
    GROUP_CONCAT(direction, ' -> ') AS 'Směry'
FROM frames_before_ack
WHERE rn <= 5
GROUP BY ack_id
ORDER BY ack_ts
LIMIT 30;

SELECT '' AS '';

-- Přehled nejčastějších typů rámců před Setting ACK
SELECT 'Nejčastější rámce před Setting ACK:' AS '';
SELECT 
    frame_type AS 'Typ rámce',
    direction AS 'Směr',
    COUNT(*) AS 'Počet výskytů',
    ROUND(AVG(delta_s), 2) AS 'Prům. čas před ACK (s)',
    MIN(delta_s) AS 'Min delta (s)',
    MAX(delta_s) AS 'Max delta (s)'
FROM (
    SELECT 
        a.id AS ack_id,
        f.id AS frame_id,
        CASE 
            WHEN f.raw LIKE '%Result>IsNewSet%' OR f.parsed LIKE '%"Result": "IsNewSet"%' THEN 'IsNewSet'
            WHEN f.raw LIKE '%Result>IsNewFW%' OR f.parsed LIKE '%"Result": "IsNewFW"%' THEN 'IsNewFW'
            WHEN f.raw LIKE '%GetActual%' OR f.parsed LIKE '%GetActual%' THEN 'GetActual'
            WHEN f.raw LIKE '%ACK%' OR f.parsed LIKE '%ACK%' THEN 'ACK'
            WHEN f.table_name LIKE '%tbl_%_prms%' THEN 'tbl_*_prms (Setting z cloudu)'
            WHEN f.table_name = 'tbl_events' THEN 'tbl_events'
            WHEN f.table_name = 'tbl_actual' THEN 'tbl_actual'
            ELSE COALESCE(f.table_name, 'other')
        END AS frame_type,
        f.direction,
        STRFTIME('%s', a.ts) - STRFTIME('%s', f.ts) AS delta_s,
        ROW_NUMBER() OVER (PARTITION BY a.id ORDER BY f.ts DESC) AS rn
    FROM frames a
    JOIN frames f ON (f.conn_id = a.conn_id OR (f.conn_id IS NULL AND f.device_id = a.device_id))
                  AND f.ts < a.ts 
                  AND f.ts >= DATETIME(a.ts, '-60 seconds')
    WHERE a.direction = 'box_to_proxy' 
      AND a.table_name = 'tbl_events'
      AND (a.raw LIKE '%Type>Setting%' OR a.parsed LIKE '%"Type": "Setting"%')
)
WHERE rn <= 5
GROUP BY frame_type, direction
ORDER BY COUNT(*) DESC;

SELECT '' AS '';

-- ============================================================================
-- H4.3: PATTERNS - Je IsNewSet vždy před Setting?
-- ============================================================================

SELECT '==========' AS '';
SELECT 'H4.3: PATTERN ANALÝZA - IsNewSet před Setting?' AS '';
SELECT '==========' AS '';
SELECT '' AS '';

-- Pro payloads.db: Kolik Settings má IsNewSet v předchozích 30s?
SELECT 'Payloads.db - IsNewSet před Setting (30s okno):' AS '';
SELECT 
    CASE 
        WHEN has_isnewset = 1 THEN 'S IsNewSet před'
        ELSE 'BEZ IsNewSet před'
    END AS 'Kategorie',
    COUNT(*) AS 'Počet Settings',
    ROUND(100.0 * COUNT(*) / (SELECT COUNT(*) FROM frames 
                               WHERE direction = 'proxy_to_cloud' 
                                 AND (raw LIKE '%tbl_%_prms%' OR parsed LIKE '%tbl_%_prms%')), 2) AS 'Procento'
FROM (
    SELECT 
        s.id,
        CASE WHEN EXISTS (
            SELECT 1 FROM frames f 
            WHERE f.device_id = s.device_id 
              AND f.ts < s.ts 
              AND f.ts >= DATETIME(s.ts, '-30 seconds')
              AND (f.raw LIKE '%Result>IsNewSet%' OR f.parsed LIKE '%"Result": "IsNewSet"%')
              AND f.direction = 'box_to_proxy'
        ) THEN 1 ELSE 0 END AS has_isnewset
    FROM frames s
    WHERE s.direction = 'proxy_to_cloud' 
      AND (s.raw LIKE '%tbl_%_prms%' OR s.parsed LIKE '%tbl_%_prms%')
) subq
GROUP BY has_isnewset;

SELECT '' AS '';

-- Pro payloads_ha_full.db: Kolik ACK má IsNewSet v předchozích 30s?
SELECT 'Payloads_ha_full.db - IsNewSet před Setting ACK (30s okno):' AS '';
SELECT 
    CASE 
        WHEN has_isnewset = 1 THEN 'S IsNewSet před'
        ELSE 'BEZ IsNewSet před'
    END AS 'Kategorie',
    COUNT(*) AS 'Počet ACK',
    ROUND(100.0 * COUNT(*) / NULLIF((SELECT COUNT(*) FROM frames 
                               WHERE direction = 'box_to_proxy' 
                                 AND table_name = 'tbl_events'
                                 AND (raw LIKE '%Type>Setting%' OR parsed LIKE '%"Type": "Setting"%')), 0), 2) AS 'Procento'
FROM (
    SELECT 
        a.id,
        CASE WHEN EXISTS (
            SELECT 1 FROM frames f 
            WHERE (f.conn_id = a.conn_id OR (f.conn_id IS NULL AND f.device_id = a.device_id))
              AND f.ts < a.ts 
              AND f.ts >= DATETIME(a.ts, '-30 seconds')
              AND (f.raw LIKE '%Result>IsNewSet%' OR f.parsed LIKE '%"Result": "IsNewSet"%')
              AND f.direction = 'box_to_proxy'
        ) THEN 1 ELSE 0 END AS has_isnewset
    FROM frames a
    WHERE a.direction = 'box_to_proxy' 
      AND a.table_name = 'tbl_events'
      AND (a.raw LIKE '%Type>Setting%' OR a.parsed LIKE '%"Type": "Setting"%')
) subq
GROUP BY has_isnewset;

SELECT '' AS '';

-- ============================================================================
-- H4.4: TIMING ANALÝZA
-- ============================================================================

SELECT '==========' AS '';
SELECT 'H4.4: TIMING ANALÝZA' AS '';
SELECT '==========' AS '';
SELECT '' AS '';

-- Timing: IsNewSet -> Setting (payloads.db)
SELECT 'Payloads.db - Čas od posledního IsNewSet do Setting:' AS '';
SELECT 
    COUNT(*) AS 'Počet párů',
    ROUND(AVG(delta_s), 2) AS 'Prům. delta (s)',
    ROUND(MIN(delta_s), 2) AS 'Min delta (s)',
    ROUND(MAX(delta_s), 2) AS 'Max delta (s)',
    ROUND(AVG(delta_s) / 60, 2) AS 'Prům. delta (min)'
FROM (
    SELECT 
        s.id,
        s.ts AS setting_ts,
        MAX(f.ts) AS last_isnewset_ts,
        STRFTIME('%s', s.ts) - STRFTIME('%s', MAX(f.ts)) AS delta_s
    FROM frames s
    JOIN frames f ON f.device_id = s.device_id 
                  AND f.ts < s.ts 
                  AND f.ts >= DATETIME(s.ts, '-60 seconds')
                  AND (f.raw LIKE '%Result>IsNewSet%' OR f.parsed LIKE '%"Result": "IsNewSet"%')
                  AND f.direction = 'box_to_proxy'
    WHERE s.direction = 'proxy_to_cloud' 
      AND (s.raw LIKE '%tbl_%_prms%' OR s.parsed LIKE '%tbl_%_prms%')
    GROUP BY s.id
) pairs;

SELECT '' AS '';

-- Timing: Poslední rámec -> Setting ACK (payloads_ha_full.db)
SELECT 'Payloads_ha_full.db - Čas od posledního rámce do Setting ACK:' AS '';
SELECT 
    COUNT(*) AS 'Počet ACK',
    ROUND(AVG(delta_s), 2) AS 'Prům. delta (s)',
    ROUND(MIN(delta_s), 2) AS 'Min delta (s)',
    ROUND(MAX(delta_s), 2) AS 'Max delta (s)'
FROM (
    SELECT 
        a.id,
        a.ts AS ack_ts,
        MAX(f.ts) AS last_frame_ts,
        STRFTIME('%s', a.ts) - STRFTIME('%s', MAX(f.ts)) AS delta_s
    FROM frames a
    JOIN frames f ON (f.conn_id = a.conn_id OR (f.conn_id IS NULL AND f.device_id = a.device_id))
                  AND f.ts < a.ts 
                  AND f.ts >= DATETIME(a.ts, '-60 seconds')
                  AND f.id != a.id
    WHERE a.direction = 'box_to_proxy' 
      AND a.table_name = 'tbl_events'
      AND (a.raw LIKE '%Type>Setting%' OR a.parsed LIKE '%"Type": "Setting"%')
    GROUP BY a.id
) pairs;

SELECT '' AS '';

-- Timing: IsNewSet -> Setting ACK (payloads_ha_full.db)
SELECT 'Payloads_ha_full.db - Čas od posledního IsNewSet do Setting ACK:' AS '';
SELECT 
    COUNT(*) AS 'Počet párů',
    ROUND(AVG(delta_s), 2) AS 'Prům. delta (s)',
    ROUND(MIN(delta_s), 2) AS 'Min delta (s)',
    ROUND(MAX(delta_s), 2) AS 'Max delta (s)'
FROM (
    SELECT 
        a.id,
        a.ts AS ack_ts,
        MAX(f.ts) AS last_isnewset_ts,
        STRFTIME('%s', a.ts) - STRFTIME('%s', MAX(f.ts)) AS delta_s
    FROM frames a
    JOIN frames f ON (f.conn_id = a.conn_id OR (f.conn_id IS NULL AND f.device_id = a.device_id))
                  AND f.ts < a.ts 
                  AND f.ts >= DATETIME(a.ts, '-60 seconds')
                  AND (f.raw LIKE '%Result>IsNewSet%' OR f.parsed LIKE '%"Result": "IsNewSet"%')
                  AND f.direction = 'box_to_proxy'
    WHERE a.direction = 'box_to_proxy' 
      AND a.table_name = 'tbl_events'
      AND (a.raw LIKE '%Type>Setting%' OR a.parsed LIKE '%"Type": "Setting"%')
    GROUP BY a.id
) pairs;

SELECT '' AS '';

-- ============================================================================
-- SHRNUTÍ HYPOTÉZ
-- ============================================================================

SELECT '========================================' AS '';
SELECT 'SHRNUTÍ HYPOTÉZ H2 + H4' AS '';
SELECT '========================================' AS '';
SELECT '' AS '';

-- H2 Shrnutí: Formát IsNewSet
SELECT 'H2 - Formát IsNewSet:' AS '';
SELECT 
    CASE 
        WHEN short_count > 0 AND long_count = 0 THEN 'PODPOROVÁNO: Pouze SHORT IsNewSet (121-124B)'
        WHEN long_count > 0 AND short_count = 0 THEN 'PODPOROVÁNO: Pouze LONG IsNewSet (>=700B)'
        WHEN short_count > 0 AND long_count > 0 THEN 'PŘECHOD DETEKOVÁN: SHORT i LONG IsNewSet přítomny'
        ELSE 'NEURČITÉ: Žádné IsNewSet rámce'
    END AS 'Verdikt',
    short_count AS 'SHORT rámce',
    long_count AS 'LONG rámce'
FROM (
    SELECT 
        SUM(CASE WHEN length <= 150 THEN 1 ELSE 0 END) AS short_count,
        SUM(CASE WHEN length >= 700 THEN 1 ELSE 0 END) AS long_count
    FROM frames 
    WHERE (raw LIKE '%Result>IsNewSet%' OR parsed LIKE '%"Result": "IsNewSet"%')
      AND direction = 'box_to_proxy'
) counts;

SELECT '' AS '';

-- H4 Shrnutí: IsNewSet před Setting pattern
SELECT 'H4 - IsNewSet před Setting pattern:' AS '';
SELECT 
    'viz výše sekce H4.3' AS 'Verdikt zkontroluj';
    
SELECT '' AS '';
SELECT 'KONEC ANALÝZY' AS '';
