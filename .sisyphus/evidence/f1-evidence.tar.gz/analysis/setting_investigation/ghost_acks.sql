-- ============================================================================
-- GHOST ACKs INVESTIGATION - Analýza phantom ACK potvrzení nastavení
-- ============================================================================
-- Účel: Analyzovat ghost ACK vzory a poskytnout důkazy pro testování hypotéz
-- Databáze: payloads_ha_full.db (analysis/ha_snapshot/)
-- Ghost ACK = ACK bez odpovídajícího Setting v téže databázi
-- ============================================================================

-- Parametry pro analýzu
-- DB_PATH: analysis/ha_snapshot/payloads_ha_full.db
-- Časové období: 2025-12-18 až 2026-01-23 (vyloučit Feb 16, 2026 mock data)

-- ============================================================================
-- SEKCE 1: Celkový přehled Setting ACKs
-- ============================================================================
SELECT '========================================' as '';
SELECT 'SEKCE 1: Celkový přehled Setting ACKs' as '';
SELECT '========================================' as '';

-- 1.1 Počet všech Setting ACKs (dvě definice)
SELECT 
    '1.1a' as metric,
    'Setting ACKs (Result=ACK, Reason=Setting)' as description,
    COUNT(*) as count
FROM frames 
WHERE direction='box_to_proxy' 
  AND raw LIKE '%Result>ACK%' 
  AND raw LIKE '%Reason>Setting%'

UNION ALL

SELECT 
    '1.1b' as metric,
    'tbl_events s Type=Setting' as description,
    COUNT(*) as count
FROM frames 
WHERE direction='box_to_proxy' 
  AND parsed LIKE '%"Type": "Setting"%';

-- 1.2 Počet odchozích Settings (proxy_to_cloud)
SELECT 
    '1.2' as metric,
    'Odchozí Settings (proxy_to_cloud)' as description,
    COUNT(*) as count
FROM frames 
WHERE direction='proxy_to_cloud';

-- 1.3 Závěr: Všechny ACKs jsou ghost ACKs
SELECT 
    '1.3' as metric,
    'Ghost ACKs (ACKs bez matching Setting)' as description,
    1031 as ghost_ack_count,
    0 as cloud_settings_count,
    '100% ghost ACKs' as conclusion;

-- ============================================================================
-- SEKCE 2: Časové rozmezí a distribuce
-- ============================================================================
SELECT '' as '';
SELECT '========================================' as '';
SELECT 'SEKCE 2: Časové rozmezí a distribuce' as '';
SELECT '========================================' as '';

-- 2.1 Časové rozmezí Setting ACKs
SELECT 
    '2.1' as metric,
    'První Setting ACK' as description,
    MIN(ts) as first_ack
FROM frames 
WHERE direction='box_to_proxy' 
  AND raw LIKE '%Result>ACK%' 
  AND raw LIKE '%Reason>Setting%'

UNION ALL

SELECT 
    '' as metric,
    'Poslední Setting ACK' as description,
    MAX(ts) as last_ack
FROM frames 
WHERE direction='box_to_proxy' 
  AND raw LIKE '%Result>ACK%' 
  AND raw LIKE '%Reason>Setting%';

-- 2.2 Denní distribuce Setting ACKs
SELECT 
    '2.2' as metric,
    DATE(ts) as day,
    COUNT(*) as ack_count
FROM frames 
WHERE direction='box_to_proxy' 
  AND raw LIKE '%Result>ACK%' 
  AND raw LIKE '%Reason>Setting%'
GROUP BY day
ORDER BY day;

-- 2.3 Dny s největším počtem ghost ACKs
SELECT 
    '2.3' as metric,
    DATE(ts) as day,
    COUNT(*) as ack_count,
    CASE 
        WHEN COUNT(*) > 50 THEN 'HIGH'
        WHEN COUNT(*) > 20 THEN 'MEDIUM'
        ELSE 'LOW'
    END as intensity
FROM frames 
WHERE direction='box_to_proxy' 
  AND raw LIKE '%Result>ACK%' 
  AND raw LIKE '%Reason>Setting%'
GROUP BY day
HAVING COUNT(*) > 10
ORDER BY ack_count DESC
LIMIT 10;

-- ============================================================================
-- SEKCE 3: Hodinová analýza (Time-of-Day)
-- ============================================================================
SELECT '' as '';
SELECT '========================================' as '';
SELECT 'SEKCE 3: Hodinová analýza (Time-of-Day)' as '';
SELECT '========================================' as '';

-- 3.1 Hodinová distribuce ghost ACKs
SELECT 
    '3.1' as metric,
    CAST(strftime('%H', ts) AS INTEGER) as hour_utc,
    COUNT(*) as ack_count,
    ROUND(COUNT(*) * 100.0 / 1031, 1) as percentage
FROM frames 
WHERE direction='box_to_proxy' 
  AND raw LIKE '%Result>ACK%' 
  AND raw LIKE '%Reason>Setting%'
GROUP BY hour_utc
ORDER BY hour_utc;

-- 3.2 Peak hodiny (top 5)
SELECT 
    '3.2' as metric,
    CAST(strftime('%H', ts) AS INTEGER) as hour_utc,
    COUNT(*) as ack_count
FROM frames 
WHERE direction='box_to_proxy' 
  AND raw LIKE '%Result>ACK%' 
  AND raw LIKE '%Reason>Setting%'
GROUP BY hour_utc
ORDER BY ack_count DESC
LIMIT 5;

-- ============================================================================
-- SEKCE 4: Interval mezi consecutive ACKs
-- ============================================================================
SELECT '' as '';
SELECT '========================================' as '';
SELECT 'SEKCE 4: Interval mezi consecutive ACKs' as '';
SELECT '========================================' as '';

-- 4.1 Statistika intervalů
WITH ack_list AS (
    SELECT 
        id, ts,
        LAG(ts) OVER (ORDER BY ts) as prev_ts
    FROM frames 
    WHERE direction='box_to_proxy' 
        AND raw LIKE '%Result>ACK%' 
        AND raw LIKE '%Reason>Setting%'
)
SELECT 
    '4.1' as metric,
    ROUND(AVG(CAST((julianday(ts) - julianday(prev_ts)) * 86400 AS REAL)), 1) as avg_interval_sec,
    ROUND(MIN(CAST((julianday(ts) - julianday(prev_ts)) * 86400 AS REAL)), 1) as min_interval_sec,
    ROUND(MAX(CAST((julianday(ts) - julianday(prev_ts)) * 86400 AS REAL)), 1) as max_interval_sec,
    '~50 min' as avg_interval_human,
    'NOT regular intervals → NOT replay' as conclusion
FROM ack_list
WHERE prev_ts IS NOT NULL;

-- 4.2 Distribuce intervalů (kategorizovaná)
WITH ack_list AS (
    SELECT 
        id, ts,
        LAG(ts) OVER (ORDER BY ts) as prev_ts
    FROM frames 
    WHERE direction='box_to_proxy' 
        AND raw LIKE '%Result>ACK%' 
        AND raw LIKE '%Reason>Setting%'
),
intervals AS (
    SELECT 
        CAST((julianday(ts) - julianday(prev_ts)) * 86400 AS INTEGER) as interval_sec
    FROM ack_list
    WHERE prev_ts IS NOT NULL
)
SELECT 
    '4.2' as metric,
    CASE 
        WHEN interval_sec < 10 THEN '< 10 sec'
        WHEN interval_sec < 60 THEN '10-60 sec'
        WHEN interval_sec < 300 THEN '1-5 min'
        WHEN interval_sec < 3600 THEN '5-60 min'
        WHEN interval_sec < 86400 THEN '1-24 hours'
        ELSE '> 24 hours'
    END as interval_range,
    COUNT(*) as count,
    ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM intervals), 1) as percentage
FROM intervals
GROUP BY interval_range
ORDER BY 
    CASE interval_range
        WHEN '< 10 sec' THEN 1
        WHEN '10-60 sec' THEN 2
        WHEN '1-5 min' THEN 3
        WHEN '5-60 min' THEN 4
        WHEN '1-24 hours' THEN 5
        ELSE 6
    END;

-- ============================================================================
-- SEKCE 5: DT pole analýza (Rdt timestamp)
-- ============================================================================
SELECT '' as '';
SELECT '========================================' as '';
SELECT 'SEKCE 5: DT pole analýza (Rdt timestamp)' as '';
SELECT '========================================' as '';

-- 5.1 Formát Rdt pole v raw XML
SELECT 
    '5.1' as metric,
    'Příklad Rdt pole v ACK frame' as description,
    id,
    ts as frame_timestamp_utc,
    substr(raw, instr(raw, '<Rdt>') + 5, 19) as rdt_local_time
FROM frames 
WHERE direction='box_to_proxy' 
    AND raw LIKE '%Result>ACK%' 
    AND raw LIKE '%Reason>Setting%'
LIMIT 3;

-- 5.2 Porovnání Rdt vs frame timestamp
WITH ack_analysis AS (
    SELECT 
        id, ts,
        substr(raw, instr(raw, '<Rdt>') + 5, 19) as rdt_raw,
        -- Převedeme ts na CET (UTC+1) pro porovnání
        strftime('%Y-%m-%d %H:%M:%S', ts, '+1 hour') as ts_cet,
        -- Spočítáme rozdíl v sekundách
        CAST((julianday(substr(raw, instr(raw, '<Rdt>') + 5, 19)) - 
              julianday(ts, '+1 hour')) * 86400 AS INTEGER) as diff_seconds
    FROM frames 
    WHERE direction='box_to_proxy' 
        AND raw LIKE '%Result>ACK%' 
        AND raw LIKE '%Reason>Setting%'
)
SELECT 
    '5.2' as metric,
    ROUND(AVG(ABS(diff_seconds)), 1) as avg_diff_seconds,
    MIN(diff_seconds) as min_diff_seconds,
    MAX(diff_seconds) as max_diff_seconds,
    CASE 
        WHEN MAX(ABS(diff_seconds)) < 60 THEN 'Rdt ~ frame_ts → REAL-TIME ACKs'
        ELSE 'Rdt significantly different → possible REPLAY'
    END as conclusion
FROM ack_analysis;

-- 5.3 Outliers - ACKs s velkým rozdílem mezi Rdt a frame timestamp
WITH ack_analysis AS (
    SELECT 
        id, ts,
        substr(raw, instr(raw, '<Rdt>') + 5, 19) as rdt_raw,
        CAST((julianday(substr(raw, instr(raw, '<Rdt>') + 5, 19)) - 
              julianday(ts, '+1 hour')) * 86400 AS INTEGER) as diff_seconds
    FROM frames 
    WHERE direction='box_to_proxy' 
        AND raw LIKE '%Result>ACK%' 
        AND raw LIKE '%Reason>Setting%'
)
SELECT 
    '5.3' as metric,
    id,
    ts as frame_ts_utc,
    rdt_raw as rdt_local,
    diff_seconds as rdt_minus_frame_cet_sec,
    CASE 
        WHEN ABS(diff_seconds) > 60 THEN 'LARGE DIFF - suspect'
        ELSE 'Normal network latency'
    END as assessment
FROM ack_analysis
ORDER BY ABS(diff_seconds) DESC
LIMIT 10;

-- ============================================================================
-- SEKCE 6: Testování hypotéz
-- ============================================================================
SELECT '' as '';
SELECT '========================================' as '';
SELECT 'SEKCE 6: Testování hypotéz' as '';
SELECT '========================================' as '';

-- Hypotéza A: Cloud poslal Settings, ale proxy nezachytila (capture bug)
SELECT 
    'Hypotéza A' as hypothesis,
    'Capture bug - proxy nezachytila odchozí Settings' as description,
    'Důkaz 1: proxy_to_cloud frames = 0' as evidence_1,
    'Důkaz 2: ACKs have varying intervals (not regular)' as evidence_2,
    'Důkaz 3: Rdt matches frame timestamp (real-time)' as evidence_3,
    'SUPPORTED' as verdict,
    'Proxy captures only box→proxy and cloud→proxy, NOT proxy→cloud' as explanation;

-- Hypotéza B: BOX přehrává staré ACKs (replay pattern)
SELECT 
    'Hypotéza B' as hypothesis,
    'BOX přehrává staré ACKs' as description,
    'Důkaz 1: Max Rdt-frame diff = ~16 sec (within network latency)' as evidence_1,
    'Důkaz 2: Intervals vary widely (4.7s to 17 hours)' as evidence_2,
    'Důkaz 3: Hourly distribution shows user activity pattern' as evidence_3,
    'REFUTED' as verdict,
    'Rdt timestamps match real-time, no replay pattern detected' as explanation;

-- Hypotéza C: Settings přišly jiným kanálem (not through proxy)
SELECT 
    'Hypotéza C' as hypothesis,
    'Settings přišly jiným kanálem' as description,
    'Důkaz 1: BOX generates ACKs in real-time (Rdt ~ frame_ts)' as evidence_1,
    'Důkaz 2: ACK Content shows "Remotely : tbl_*_prms" (remote settings)' as evidence_2,
    'Důkaz 3: No proxy_to_cloud traffic captured' as evidence_3,
    'INCONCLUSIVE' as verdict,
    'Possible but cannot verify without full capture' as explanation;

-- ============================================================================
-- SEKCE 7: Verifikace známých případů
-- ============================================================================
SELECT '' as '';
SELECT '========================================' as '';
SELECT 'SEKCE 7: Verifikace známých případů' as '';
SELECT '========================================' as '';

-- 7.1 Jan 23, 2026 - očekáváno 7 ghost ACKs
SELECT 
    '7.1' as metric,
    'Jan 23, 2026 ghost ACKs' as description,
    COUNT(*) as actual_count,
    7 as expected_count,
    CASE WHEN COUNT(*) = 7 THEN 'MATCH' ELSE 'DIFFERENT' END as verification
FROM frames 
WHERE direction='box_to_proxy' 
    AND raw LIKE '%Result>ACK%' 
    AND raw LIKE '%Reason>Setting%'
    AND ts LIKE '2026-01-23%';

-- 7.2 Detail Jan 23, 2026 ACKs
SELECT 
    '7.2' as metric,
    id,
    ts as frame_timestamp,
    substr(raw, instr(raw, '<Rdt>') + 5, 19) as rdt
FROM frames 
WHERE direction='box_to_proxy' 
    AND raw LIKE '%Result>ACK%' 
    AND raw LIKE '%Reason>Setting%'
    AND ts LIKE '2026-01-23%'
ORDER BY ts;

-- 7.3 Poslední známý cloud Setting - Jan 4, 2026 17:37:40 UTC
SELECT 
    '7.3' as metric,
    'Poslední cloud Setting (z payloads.db)' as description,
    '2026-01-04 17:37:40 UTC' as last_known_setting,
    MAX(ts) as last_ack_in_db,
    ROUND((julianday(MAX(ts)) - julianday('2026-01-04T17:37:40')) * 24, 1) as days_gap
FROM frames 
WHERE direction='box_to_proxy' 
    AND raw LIKE '%Result>ACK%' 
    AND raw LIKE '%Reason>Setting%';

-- 7.4 Cloud Settings v payloads_ha_full.db
SELECT 
    '7.4' as metric,
    'Cloud Settings v payloads_ha_full.db' as description,
    COUNT(*) as count,
    CASE WHEN COUNT(*) = 0 THEN 'CONFIRMED: 0 Settings' ELSE 'UNEXPECTED' END as verification
FROM frames 
WHERE direction='proxy_to_cloud';

-- ============================================================================
-- SEKCE 8: Shrnutí a závěry
-- ============================================================================
SELECT '' as '';
SELECT '========================================' as '';
SELECT 'SEKCE 8: Shrnutí a závěry' as '';
SELECT '========================================' as '';

SELECT 
    'SHRNUTÍ' as section,
    'Ghost ACKs Investigation' as title,
    '' as '';

SELECT 
    'Zjištění' as category,
    'Celkový počet ghost ACKs' as finding,
    '1031' as value,
    '100% ACKs bez matching Setting' as note

UNION ALL

SELECT 
    'Zjištění' as category,
    'Proxy capture gap' as finding,
    '0 proxy_to_cloud frames' as value,
    'Proxy nezachytává odchozí Settings' as note

UNION ALL

SELECT 
    'Zjištění' as category,
    'Rdt timestamp analýza' as finding,
    'max 16 sec diff' as value,
    'ACKs jsou real-time, ne replay' as note

UNION ALL

SELECT 
    'Zjištění' as category,
    'Interval mezi ACKs' as finding,
    '4.7s - 17h (avg 50min)' as value,
    'Není pravidelný - není replay' as note

UNION ALL

SELECT 
    'Zjištění' as category,
    'Hodinová distribuce' as finding,
    'Peak: 20:00, 12:00, 10:00' as value,
    'Odpovídá aktivitě uživatele' as note

UNION ALL

SELECT 
    'Verdikt' as category,
    'Hypotéza A (Capture bug)' as finding,
    'SUPPORTED' as value,
    'Proxy nezachytává proxy_to_cloud směr' as note

UNION ALL

SELECT 
    'Verdikt' as category,
    'Hypotéza B (Replay pattern)' as finding,
    'REFUTED' as value,
    'Rdt timestamps jsou real-time' as note

UNION ALL

SELECT 
    'Verdikt' as category,
    'Hypotéza C (Different channel)' as finding,
    'INCONCLUSIVE' as value,
    'Nelze ověřit bez plného capture' as note;

-- ============================================================================
-- POZNÁMKY K INTERPRETACI
-- ============================================================================
-- 
-- 1. Ghost ACKs definice:
--    - V této DB je každý Setting ACK "ghost" protože neexistují odpovídající
--      odchozí Settings (proxy_to_cloud direction = 0 frames)
--
-- 2. Proč proxy_to_cloud = 0:
--    - Proxy capture pravděpodobně zachytává pouze box→proxy a cloud→proxy
--      směry, ale NE proxy→cloud směr
--    - To znamená, že Settings BYLY odeslány do cloudu, ale nebyly zachyceny
--
-- 3. Rdt pole:
--    - Formát: YYYY-MM-DD HH:MM:SS (lokální čas BOXu)
--    - Posun o ~1 hodinu oproti UTC timestampu frame (CET timezone)
--    - Rozdíl max 16 sekund = normální latence sítě
--
-- 4. Doporučení:
--    - Přidat capture proxy_to_cloud směru pro kompletní monitoring
--    - Nebo použít jinou DB (payloads.db) která má outgoing Settings
--
-- ============================================================================
