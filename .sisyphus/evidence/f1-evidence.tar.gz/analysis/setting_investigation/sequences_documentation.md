# Kompletní sekvence funkčního Setting delivery

## KRITICKÉ ZJIŠTĚNÍ

**Databáze jsou KOMPLEMENTÁRNÍ, ne překrývající se:**
- `payloads.db` (Dec 11-12, 2025): Má odchozí Settings (209), ale ŽÁDNÉ Setting ACKs (tbl_events Type="Setting")
- `payloads_ha_full.db` (Dec 18, 2025 - Jan 23, 2026): Má Setting ACKs (767), ale ŽÁDNÉ odchozí Settings

**Kompletní párované sekvence (Setting→ACK) jsou NEMOŽNÉ s aktuálními daty!**

---

## Sekvence 1: payloads.db - Reprezentativní Setting

### Setting id=966 (tbl_box_prms)
- **Timestamp**: 2025-12-11 18:06:10 UTC
- **Směr**: proxy_to_cloud
- **Tabulka**: tbl_box_prms
- **Délka**: 990 bytes
- **Obsah**:
```json
{
  "_table": "tbl_box_prms",
  "_device_id": "2206237016",
  "_dt": "2025-12-11 19:05:00",
  "ISON": 1,
  "MODE": 0,
  "BAT_MIN": 20,
  "BAT_AC": 80,
  "P_FVE": 5400,
  "P_BAT": 15360,
  "P_GRID": 16000,
  "P_LOAD": 16000,
  "SW": "v.4.4.43.0716",
  "IP": "185.25.185.30",
  "PORT": 5710,
  "DOMAIN": "oig..."
}
```

### Rámy kolem Setting (±2min, 18:05:00 - 18:07:30)

| id | timestamp | direction | table_name | length | role |
|----|-----------|-----------|------------|--------|------|
| 957 | 18:05:58 | box_to_proxy | tbl_batt_prms | 577 | BOX DATA |
| 958 | 18:05:58 | proxy_to_cloud | tbl_batt_prms | 577 | **>>> SETTING** |
| 959 | 18:05:58 | cloud_to_proxy | tbl_batt_prms | 75 | <<< CLOUD ACK |
| 960 | 18:05:58 | proxy_to_box | tbl_batt_prms | 75 | |
| 961 | 18:06:03 | box_to_proxy | tbl_invertor_prms | 638 | BOX DATA |
| 962 | 18:06:03 | proxy_to_cloud | tbl_invertor_prms | 638 | **>>> SETTING** |
| 963 | 18:06:03 | cloud_to_proxy | tbl_invertor_prms | 75 | <<< CLOUD ACK |
| 964 | 18:06:03 | proxy_to_box | tbl_invertor_prms | 75 | |
| 965 | 18:06:10 | box_to_proxy | tbl_box_prms | 990 | BOX DATA |
| **966** | **18:06:10** | **proxy_to_cloud** | **tbl_box_prms** | **990** | **>>> SETTING** |
| 967 | 18:06:10 | cloud_to_proxy | tbl_box_prms | 75 | <<< CLOUD ACK |
| 968 | 18:06:10 | proxy_to_box | tbl_box_prms | 75 | |
| 969 | 18:06:15 | box_to_proxy | tbl_box | 294 | |
| ... | ... | ... | ... | ... | |

### Protokolová sekvence v payloads.db:
```
box_to_proxy (param table) -> proxy_to_cloud (SETTING) -> cloud_to_proxy (75B ACK) -> proxy_to_box (forward)
```

### Poznámky:
- ✅ Cloud potvrzuje přijetí protokolovým ACK (75 bytes)
- ❌ ŽÁDNÉ Setting ACKs (tbl_events Type="Setting") v payloads.db
- ❌ ŽÁDNÉ GetActual v payloads.db (proxy neinjektoval v Dec 11-12 období)

---

## Sekvence 2: payloads.db - Shrnutí všech 209 Settings

### Celkové statistiky:
- **Celkem Settings**: 209
- **První Setting**: 2025-12-11 15:20:22 UTC
- **Poslední Setting**: 2025-12-12 18:37:34 UTC
- **Časové rozpětí**: ~27 hodin

### Podle tabulky:
| Tabulka | Počet | Procento |
|---------|-------|----------|
| tbl_batt_prms | 140 | 67.0% |
| tbl_invertor_prms | 52 | 24.9% |
| tbl_box_prms | 15 | 7.2% |
| tbl_boiler_prms | 2 | 1.0% |

### Časová distribuce:
| Den | Hodina | Počet | Dominantní tabulka |
|-----|--------|-------|-------------------|
| Dec 11 | 15:00 | 2 | tbl_invertor_prms |
| Dec 11 | 18:00 | 10 | tbl_batt_prms |
| Dec 11 | 19:00 | 16 | tbl_batt_prms |
| Dec 11 | 20:00 | 14 | tbl_batt_prms |
| Dec 11 | 21:00 | 21 | tbl_batt_prms |
| Dec 11 | 22:00 | 16 | tbl_batt_prms |
| Dec 11 | 23:00 | 11 | tbl_batt_prms |
| Dec 12 | 00:00 | 13 | tbl_batt_prms |
| Dec 12 | 01:00 | 2 | tbl_batt_prms |
| Dec 12 | 02:00 | 17 | tbl_box_prms |
| ... | ... | ... | ... |
| Dec 12 | 18:00 | 7 | tbl_batt_prms |

### Patterny:
1. **Baterie dominantní**: 67% Settings je tbl_batt_prms
2. **Hustá aktivita večer**: 18:00-23:00 má nejvíce Settings
3. **Noční aktivita**: 00:00-02:00 má výraznou aktivitu
4. **Ranní minimum**: 06:00-12:00 má minimální aktivitu

---

## Sekvence 3: payloads_ha_full.db - Reprezentativní Setting ACK

### Setting ACK id=263 (tbl_events)
- **Timestamp**: 2025-12-18 19:26:59 UTC
- **Směr**: box_to_proxy
- **Tabulka**: tbl_events
- **conn_id**: 2
- **Délka**: 291 bytes
- **Obsah**:
```json
{
  "_table": "tbl_events",
  "_device_id": "2206237016",
  "_dt": "2025-12-18 20:26:21",
  "Type": "Setting",
  "Confirm": "NoNeed",
  "Content": "Remotely : tbl_box_prms / MODE: [3]->[0]"
}
```

### Rámy kolem ACK na conn_id=2 (±60s):

| id | timestamp | direction | table_name | length | role |
|----|-----------|-----------|------------|--------|------|
| **263** | **19:26:59** | **box_to_proxy** | **tbl_events** | **291** | **>>> SETTING ACK** |
| 264 | 19:26:59 | cloud_to_proxy | tbl_events | 53 | <<< CLOUD ACK |
| 265 | 19:27:03 | box_to_proxy | tbl_events | 333 | |
| 266 | 19:27:03 | cloud_to_proxy | tbl_events | 53 | |
| 267 | 19:27:10 | box_to_proxy | tbl_events | 353 | |
| 268 | 19:27:10 | cloud_to_proxy | tbl_events | 53 | |
| 269 | 19:27:14 | box_to_proxy | tbl_events | 291 | >>> SETTING ACK |
| 270 | 19:27:14 | cloud_to_proxy | tbl_events | 53 | <<< CLOUD ACK |
| 271 | 19:27:21 | box_to_proxy | tbl_box_prms | 991 | PARAM DATA |
| 272 | 19:27:21 | cloud_to_proxy | tbl_box_prms | 53 | |
| ... | ... | ... | ... | ... | |

### Protokolová sekvence v payloads_ha_full.db:
```
box_to_proxy (tbl_events Type=Setting) -> cloud_to_proxy (53B ACK)
```

### Poznámky:
- ❌ ŽÁDNÝ odchozí Setting na této conn před ACK (ghost ACK)
- ✅ Cloud potvrzuje ACK protokolovým ACK (53 bytes)
- ❌ ŽÁDNÉ GetActual v tomto časovém okně

---

## Sekvence 4: payloads_ha_full.db - Temporální distribuce ACKs

### Celkové statistiky:
- **Celkem ACKs**: 767
- **První ACK**: 2025-12-18 19:26:59 UTC
- **Poslední ACK**: 2026-01-23 05:24:21 UTC
- **Časové rozpětí**: ~36 dní

### ACKs podle dne:
| Den | Počet |
|-----|-------|
| 2025-12-18 | 60 |
| 2025-12-19 | 47 |
| 2025-12-20 | 26 |
| 2025-12-21 | 17 |
| 2025-12-22 | 15 |
| 2025-12-23 | 31 |
| 2025-12-24 | 69 |
| 2025-12-25 | 12 |
| 2025-12-26 | 13 |
| 2025-12-27 | 17 |
| 2025-12-28 | 53 |
| 2025-12-29 | 13 |
| 2025-12-30 | 26 |
| 2025-12-31 | 14 |
| 2026-01-01 | 17 |
| 2026-01-02 | 12 |
| 2026-01-03 | 18 |
| 2026-01-04 | 10 |
| 2026-01-05 | 17 |
| 2026-01-06 | 15 |
| 2026-01-07 | 22 |
| 2026-01-08 | 12 |
| 2026-01-09 | 19 |
| 2026-01-10 | 17 |
| 2026-01-11 | 9 |
| 2026-01-12 | 17 |
| 2026-01-13 | 4 |
| 2026-01-14 | 14 |
| 2026-01-15 | 19 |
| 2026-01-16 | 16 |
| 2026-01-17 | 16 |
| 2026-01-18 | 8 |
| 2026-01-19 | 7 |
| 2026-01-20 | 27 |
| 2026-01-21 | 34 |
| 2026-01-22 | 19 |
| 2026-01-23 | 5 |

### Patterny:
1. **Shluky ACKs**: Dec 18, Dec 24, Dec 28 mají nejvíce ACKs
2. **Stabilní baseline**: 10-20 ACKs denně v lednu
3. **Postupný pokles**: Od Dec 28 klesá aktivita
4. **Jan 13 minimum**: Pouze 4 ACKs

### Časová mezera od posledního cloud Setting:
- **Poslední Setting (payloads.db)**: Dec 12, 2025 18:37:34 UTC
- **První ACK (payloads_ha_full.db)**: Dec 18, 2025 19:26:59 UTC
- **Mezera**: ~6 dní

---

## KRITICKÉ ZJIŠTĚNÍ: Proč nemůžeme vytvořit kompletní sekvence

### Problém komplementarity:

```
payloads.db (Dec 11-12, 2025):
├── proxy_to_cloud: 209 Settings ✓
├── box_to_proxy: 0 Setting ACKs ✗
├── GetActual: 0 ✗
└── IsNewSet: 0 ✗

payloads_ha_full.db (Dec 18, 2025 - Jan 23, 2026):
├── proxy_to_cloud: 0 Settings ✗
├── box_to_proxy: 767 Setting ACKs ✓
├── GetActual: 275,199 ✓
└── IsNewSet: 53,060 ✓
```

### Důsledky:
1. **Nemůžeme spárovat Setting→ACK**: Žádná databáze nemá oba typy dat
2. **Ghost ACKs**: Všechny 767 ACKs v payloads_ha_full.db jsou bez odpovídajícího Setting
3. **Orphan Settings**: Všechny 209 Settings v payloads.db jsou bez odpovídajícího ACK

### Co můžeme dokumentovat:
1. ✅ Protokolovou sekvenci Settings v payloads.db
2. ✅ Protokolovou sekvenci ACKs v payloads_ha_full.db
3. ✅ Temporální distribuci obou typů
4. ❌ Kompletní Setting→ACK sekvenci (NEMOŽNÉ)

---

## Další kroky

Pro vytvoření kompletních párovaných sekvencí je potřeba:
1. Najít databázi, která obsahuje jak Settings, tak jejich ACKs
2. Nebo spojit data z obou databází na základě timestamp (nepřesné)
3. Nebo nasbírat nová data s kompletním záznamem komunikace

---

## SQL Script

Všechny dotazy jsou k dispozici v: `analysis/setting_investigation/reference_sequences.sql`

Spuštění:
```bash
# Pro payloads.db
sqlite3 ./analysis/ha_snapshot/payloads.db < analysis/setting_investigation/reference_sequences.sql

# Pro payloads_ha_full.db
sqlite3 ./analysis/ha_snapshot/payloads_ha_full.db < analysis/setting_investigation/reference_sequences.sql
```
