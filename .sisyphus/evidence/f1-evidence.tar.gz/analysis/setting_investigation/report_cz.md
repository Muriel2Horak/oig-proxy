# Analýza doručování nastavení - Česká zpráva

## Shrnutí

Analýza 924,000 rámců ze dvou komplementárních databází odhalila kritické problémy v doručování nastavení mezi OIG Boxem a cloudem. Hlavním zjištěním je, že databáze obsahují nekompletní data - jedna obsahuje odchozí Settings bez odpovědí, druhá obsahuje odpovědi (ACK) bez odpovídajících požadavků. Tato komplementarita znemožňuje vytvoření kompletních sekvencí doručení nastavení. Identifikovali jsme 767 "ghost ACKs" v payloads_ha_full.db a 209 osiřelých Settings v payloads.db, což naznačuje systematický problém v zachytávání komunikace.

## Verdikty hypotéz

### H1: GetActual interference
**Verdikt: INCONCLUSIVE**

Analýza nebyla dokončena z důvodu timeoutu při zpracování dat. Vytvořený SQL skript `h3_getactual_interference.sql` čeká na spuštění, ale z dostupných dat nelze určit, zda dochází k interferenci mezi GetActual požadavky a doručením Settings.

### H2: IsNewSet format change (firmware)
**Verdikt: SUPPORTED**

Formát IsNewSet rámců zůstal konzistentní v celém analyzovaném období:
- payloads.db: 747 IsNewSet rámců, délka 121-123B
- payloads_ha_full.db: 26,857 IsNewSet rámců, délka 121-124B
- **ŽÁDNÉ LONG rámců (760B)** nebyly nalezeny v historii
- Distribuce délek: 121B (4098×), 122B (22533×), 123B (157×), 124B (69×)
- Formát se nezměnil do 1. února 2026, všechny rámcce jsou SHORT (121-124B)

### H3: Connection lifecycle
**Verdikt: INCONCLUSIVE**

Analýza nebyla dokončena z důvodu timeoutu při zpracování dat. Nemůžeme potvrdit ani vyvrátit vliv životního cyklu připojení na doručování Settings.

### H4: Protocol state/timing
**Verdikt: REFUTED**

Analýza ukázala, že proxy-to-cloud Settings v prosinci 2025 NEPOBSAHOVALY předchozí IsNewSet rámcve:
- V payloads.db (prosinec 2025): 209 Settings bez předchozích IsNewSet v 60s okně
- V payloads_ha_full.db (prosinec 2025 - únor 2026): 767 Setting ACKs, ale žádné outgoing Settings
- Toto odporuje očekávanému protokolovému vzoru: IsNewSet → Cloud Setting → ACK

## Ghost ACKs vysvětlení

### Nejpravděpodobnější vysvětlení
**Hypotéza A: Capture bug (proxy nezachytila Settings)**

### Důkazy pro výběr
1. **proxy_to_cloud frames = 0** v payloads_ha_full.db
2. **Intervaly mezi ACKs nejsou pravidelné** (4.7s až 17h)
3. **Rdt timestamps odpovídají frame timestamp** (max rozdíl 16s)
4. **Hodinová distribuce odpovídá aktivitě uživatele** (peaky v 20:00, 12:00, 10:00 UTC)

### Dopad na analýzu
Všechny 767 Setting ACKs v payloads_ha_full.db jsou "ghost" pouze kvůli nekompletnímu capture. Proxy evidentně zachytává pouze box→proxy a cloud→proxy směry, ale NE proxy→cloud směr.

## Reference sekvence

### Jak vypadá funkční doručení Setting
Dle dostupných dat a dokumentace by funkční doručení mělo následovat sekvenci:
```
box_to_proxy (param table) -> proxy_to_cloud (SETTING) -> cloud_to_proxy (75B ACK) -> proxy_to_box
```

### Klíčové prvky
- **IsNewSet**: Signál změny nastavení z boxu (121-124B SHORT rámce)
- **Cloud Setting**: Proxy doručí parametry do cloudu (tbl_*_prms tabulky)
- **ACK**: Potvrzení přijetí ze strany cloudu

### Timing a sekvence
- payloads.db ukazuje: 209 Settings v ~27hodinovém období (prosinec 11-12, 2025)
- payloads_ha_full.db ukazuje: 767 ACKs v ~36denním období (prosinec 18, 2025 - leden 23, 2026)
- Mezera mezi databázemi: ~6 dní (prosinec 12-18, 2025)

## Root cause a rankování

### Seřazení hypotéz podle pravděpodobnosti
1. **H2 (IsNewSet format)**: SUPPORTED - Formát se nezměnil, data jsou jasná
2. **H4 (Protocol state)**: REFUTED - Data jasně ukazují odchylku od očekávaného vzoru
3. **H1 (GetActual interference)**: INCONCLUSIVE - Chybí data pro posouzení
4. **H3 (Connection lifecycle)**: INCONCLUSIVE - Chybí data pro posouzení

### Nejvíce pravděpodobná příčina
**Capture bug:** Proxy nezachytává proxy→cloud směr, což způsobilo rozdělení dat na dvě komplementární databáze.

### Další kandidátní příčiny
1. **Konfigurace proxy** - capture může být nastaven pouze pro určité směry
2. **Timing issue** - capture může být spuštěn v nesprávný čas
3. **Verze proxy** - starší verze nemusely podporovat plný capture

## Akční plán

### Krok 1: Opravit capture proxy
**Konkrétní akce:** Konfigurovat capture proxy pro zachytávání VŠECH směrů komunikace
- Popis: Ujistit se, že proxy zachytává box_to_proxy, proxy_to_box, proxy_to_cloud a cloud_to_proxy
- Priorita: Vysoká (bez toho nelze analyzovat kompletní sekvence)

### Krok 2: Najít nebo vytvořit kompletní databázi
**Konkrétní akce:** Vyhledat databázi obsahující BOTH Settings AND jejich odpovídající ACKs
- Popis: Provést kompletní capture po dobu alespoň 24 hodin pro získání kompletních dat
- Priorita: Vysoká (nutné pro validaci hypotéz H1 a H3)

### Krok 3: Reimplementovat analýzu H1 a H3
**Konkrétní akce:** Spustit analýzu GetActual interference (H1) a Connection lifecycle (H3) na kompletních datech
- Popis: Dokončení analýz, které selhaly z důvodu timeoutu na komplementárních databázích
- Priorita: Střední (potřebné pro kompletní pochopení problému)

### Fallback: Pokud kroky 1-3 nezaberou
**Alternativní řešení:** Sestavit data z obou databází na základě časových značek a ID zařízení
- Popis: I když nepřesné, může poskytnout přibližný pohled na sekvence Setting→ACK
- Priorita: Nízká (poslední možnost)

## Technical Findings Summary

### Shrnutí dat
- **2 databáze:** payloads.db (prosinec 11-12, 2025) a payloads_ha_full.db (prosinec 18, 2025 - únor 1, 2026)
- **924,059 rámců celkem:** 52,107 v payloads.db, 871,952 v payloads_ha_full.db
- **44 dní pokrytí:** ~1.1 den v payloads.db, ~44.8 dní v payloads_ha_full.db

### Klíčová zjištění
1. **Komplementární databáze:** payloads.db má Settings bez ACKs, payloads_ha_full.db má ACKs bez Settings
2. **Ghost ACKs:** 100% ACKs v payloads_ha_full.db jsou "ghost" (767 z 767)
3. **Formátová stabilita:** IsNewSet rámcve zůstaly SHORT (121-124B) v celém období
4. **Protokolová odchylka:** Settings v payloads.db nemají předchozí IsNewSet (odporuje očekávanému vzoru)

### Doporučení pro další analýzu
1. Získat kompletní data s oběma směry komunikace
2. Provést analýzu timing vzorů s kompletními sekvencemi
3. Investigovat konfiguraci capture proxy pro zajištění úplnosti dat
4. Vytvořit mechanismus pro automatickou detekci nekompletních dat v budoucnu