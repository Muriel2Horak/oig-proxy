-- ============================================================================
-- H1: Connection Lifecycle Analýza pro Setting ACKs
-- ============================================================================
-- Cíl: Analyzovat, zda se Setting ACKs vyskytují na krátkodobých spojeních,
--       která se zavírají příliš rychle (což by vysvětlovalo "ghost ACKs")
--
-- Hypotéza H1: "Ghost ACKs nastávají na krátkodobých spojeních (<20 rámců)"
--   - Pokud většina ACKs na krátkých spojeních → PODPORUJE hypotézu
--   - Pokud většina ACKs má mnoho rámců po sobě → VYVRÁCENO (spojení persistují)
--   - Pokud ACKs rovnoměrně distribuovány → NEJEDNOZNAČNÉ
--
-- Databáze: payloads_ha_full.db (analysis/ha_snapshot/)
-- Data: 767 Setting ACKs, 18,334 distinct conn_ids
-- ============================================================================

.mode column
.headers on
.width 60 20 20

-- ============================================================================
-- 1. PŘEHLED DAT
-- ============================================================================
SELECT '═══════════════════════════════════════════════════════════════════════' as '';
SELECT '1. PŘEHLED DAT - Základní statistiky' as '';
SELECT '═══════════════════════════════════════════════════════════════════════' as '';

SELECT 
    (SELECT COUNT(*) FROM frames) as total_frames,
    (SELECT COUNT(DISTINCT conn_id) FROM frames WHERE conn_id IS NOT NULL) as unique_connections,
    (SELECT COUNT(*) FROM frames WHERE direction='box_to_proxy' AND parsed LIKE '%Type%Setting%') as setting_acks,
    (SELECT COUNT(DISTINCT conn_id) FROM frames WHERE direction='box_to_proxy' AND parsed LIKE '%Type%Setting%' AND conn_id IS NOT NULL) as connections_with_acks;

-- ============================================================================
-- 2. DISTRIBUCE VELIKOSTI SPOJENÍ (OVERALL)
-- ============================================================================
SELECT '' as '';
SELECT '═══════════════════════════════════════════════════════════════════════' as '';
SELECT '2. DISTRIBUCE VELIKOSTI SPOJENÍ - Všechna spojení' as '';
SELECT '═══════════════════════════════════════════════════════════════════════' as '';
SELECT 'Očekávané hodnoty: tiny(1-5): 1981, short(6-20): 5964, medium(21-100): 8823, large(101-500): 1503, huge(500+): 63' as '';

SELECT 
    CASE 
        WHEN total_frames <= 5 THEN 'tiny(1-5)'
        WHEN total_frames <= 20 THEN 'short(6-20)'
        WHEN total_frames <= 100 THEN 'medium(21-100)'
        WHEN total_frames <= 500 THEN 'large(101-500)'
        ELSE 'huge(500+)'
    END as size_category,
    COUNT(*) as connection_count,
    ROUND(COUNT(*) * 100.0 / SUM(COUNT(*)) OVER (), 1) as pct
FROM (
    SELECT conn_id, COUNT(*) as total_frames
    FROM frames
    WHERE conn_id IS NOT NULL
    GROUP BY conn_id
)
GROUP BY 1
ORDER BY MIN(total_frames);

-- ============================================================================
-- 3. KDE SE VYSKYTUJÍ SETTING ACKs - PODLE VELIKOSTI SPOJENÍ
-- ============================================================================
SELECT '' as '';
SELECT '═══════════════════════════════════════════════════════════════════════' as '';
SELECT '3. SETTING ACKs PODLE VELIKOSTI SPOJENÍ' as '';
SELECT '═══════════════════════════════════════════════════════════════════════' as '';
SELECT 'KLÍČOVÁ OTÁZKA: Objevují se ACKs na krátkých či dlouhých spojeních?' as '';

WITH setting_acks AS (
    SELECT id, ts, conn_id
    FROM frames 
    WHERE direction='box_to_proxy' AND parsed LIKE '%Type%Setting%' AND conn_id IS NOT NULL
),
conn_total AS (
    SELECT conn_id, COUNT(*) as total_frames
    FROM frames
    WHERE conn_id IS NOT NULL
    GROUP BY conn_id
)
SELECT 
    CASE 
        WHEN ct.total_frames <= 5 THEN 'tiny(1-5)'
        WHEN ct.total_frames <= 20 THEN 'short(6-20)'
        WHEN ct.total_frames <= 100 THEN 'medium(21-100)'
        WHEN ct.total_frames <= 500 THEN 'large(101-500)'
        ELSE 'huge(500+)'
    END as size_category,
    COUNT(DISTINCT sa.conn_id) as ack_connections,
    COUNT(*) as total_acks,
    ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM setting_acks), 1) as pct_of_all_acks
FROM setting_acks sa
JOIN conn_total ct ON sa.conn_id = ct.conn_id
GROUP BY 1
ORDER BY MIN(ct.total_frames);

-- ============================================================================
-- 4. POČET RÁMŮ PŘED A PO ACK NA STEJNÉM SPOJENÍ
-- ============================================================================
SELECT '' as '';
SELECT '═══════════════════════════════════════════════════════════════════════' as '';
SELECT '4. ŽIVOTNÍ CYKLUS SPOJENÍ OKOLO ACK' as '';
SELECT '═══════════════════════════════════════════════════════════════════════' as '';
SELECT 'KLÍČOVÁ OTÁZKA: Kolik rámců je před a po ACK na stejném spojení?' as '';

WITH setting_acks AS (
    SELECT id, ts, conn_id
    FROM frames 
    WHERE direction='box_to_proxy' AND parsed LIKE '%Type%Setting%' AND conn_id IS NOT NULL
),
conn_totals AS (
    SELECT conn_id, COUNT(*) as total_frames, MIN(id) as first_id, MAX(id) as last_id
    FROM frames
    WHERE conn_id IN (SELECT DISTINCT conn_id FROM setting_acks)
    GROUP BY conn_id
)
SELECT 
    AVG(ct.total_frames) as avg_total_frames,
    AVG(ct.total_frames - (SELECT COUNT(*) FROM frames f WHERE f.conn_id = sa.conn_id AND f.id <= sa.id)) as avg_frames_after,
    AVG((SELECT COUNT(*) FROM frames f WHERE f.conn_id = sa.conn_id AND f.id < sa.id)) as avg_frames_before,
    COUNT(*) as total_acks_analyzed
FROM setting_acks sa
JOIN conn_totals ct ON sa.conn_id = ct.conn_id;

-- ============================================================================
-- 5. DISTRIBUCE: POČET RÁMŮ PO ACK
-- ============================================================================
SELECT '' as '';
SELECT '═══════════════════════════════════════════════════════════════════════' as '';
SELECT '5. DISTRIBUCE RÁMŮ PO ACK' as '';
SELECT '═══════════════════════════════════════════════════════════════════════' as '';
SELECT 'Pokud většina ACKs má mnoho rámců po sobě → HYPOTÉZA VYVRÁCENA' as '';

WITH setting_acks AS (
    SELECT id, ts, conn_id
    FROM frames 
    WHERE direction='box_to_proxy' AND parsed LIKE '%Type%Setting%' AND conn_id IS NOT NULL
),
conn_totals AS (
    SELECT conn_id, COUNT(*) as total_frames
    FROM frames
    WHERE conn_id IN (SELECT DISTINCT conn_id FROM setting_acks)
    GROUP BY conn_id
)
SELECT 
    CASE 
        WHEN frames_after = 0 THEN '0 - ACK je poslední rámec'
        WHEN frames_after <= 5 THEN '1-5 rámců po ACK'
        WHEN frames_after <= 20 THEN '6-20 rámců po ACK'
        WHEN frames_after <= 100 THEN '21-100 rámců po ACK'
        ELSE '100+ rámců po ACK'
    END as frames_after_category,
    COUNT(*) as ack_count,
    ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM setting_acks), 1) as pct
FROM (
    SELECT 
        sa.id,
        ct.total_frames - (SELECT COUNT(*) FROM frames f WHERE f.conn_id = sa.conn_id AND f.id <= sa.id) as frames_after
    FROM setting_acks sa
    JOIN conn_totals ct ON sa.conn_id = ct.conn_id
)
GROUP BY 1
ORDER BY MIN(frames_after);

-- ============================================================================
-- 6. IZOLOVANÉ ACKs (0-1 RÁMCŮ PŘED)
-- ============================================================================
SELECT '' as '';
SELECT '═══════════════════════════════════════════════════════════════════════' as '';
SELECT '6. IZOLOVANÉ ACKs - Kolik rámců před ACK?' as '';
SELECT '═══════════════════════════════════════════════════════════════════════' as '';
SELECT 'ACKs s 0-1 rámci před sebou = ACK jako první/akční rámec na spojení' as '';

WITH setting_acks AS (
    SELECT id, ts, conn_id
    FROM frames 
    WHERE direction='box_to_proxy' AND parsed LIKE '%Type%Setting%' AND conn_id IS NOT NULL
),
conn_totals AS (
    SELECT conn_id, COUNT(*) as total_frames
    FROM frames
    WHERE conn_id IN (SELECT DISTINCT conn_id FROM setting_acks)
    GROUP BY conn_id
)
SELECT 
    CASE 
        WHEN frames_before = 0 THEN '0 - ACK je první rámec'
        WHEN frames_before = 1 THEN '1 rámec před ACK'
        WHEN frames_before <= 5 THEN '2-5 rámců před ACK'
        WHEN frames_before <= 20 THEN '6-20 rámců před ACK'
        ELSE '20+ rámců před ACK'
    END as frames_before_category,
    COUNT(*) as ack_count,
    ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM setting_acks), 1) as pct
FROM (
    SELECT 
        sa.id,
        (SELECT COUNT(*) FROM frames f WHERE f.conn_id = sa.conn_id AND f.id < sa.id) as frames_before
    FROM setting_acks sa
    JOIN conn_totals ct ON sa.conn_id = ct.conn_id
)
GROUP BY 1
ORDER BY MIN(frames_before);

-- ============================================================================
-- 7. VÍCENÁSOBNÉ ACKs NA STEJNÉM SPOJENÍ
-- ============================================================================
SELECT '' as '';
SELECT '═══════════════════════════════════════════════════════════════════════' as '';
SELECT '7. VÍCENÁSOBNÉ ACKs NA STEJNÉM SPOJENÍ' as '';
SELECT '═══════════════════════════════════════════════════════════════════════' as '';
SELECT 'Pokud mnoho spojení má více ACKs → dlouhodobé spojení pattern' as '';

WITH setting_acks AS (
    SELECT id, ts, conn_id
    FROM frames 
    WHERE direction='box_to_proxy' AND parsed LIKE '%Type%Setting%' AND conn_id IS NOT NULL
)
SELECT 
    ack_count as acks_per_connection,
    COUNT(*) as connection_count,
    ROUND(COUNT(*) * 100.0 / (SELECT COUNT(DISTINCT conn_id) FROM setting_acks), 1) as pct
FROM (
    SELECT conn_id, COUNT(*) as ack_count
    FROM setting_acks
    GROUP BY conn_id
)
GROUP BY 1
ORDER BY 1;

-- ============================================================================
-- 8. ČASOVÁ DURATION PŘED A PO ACK
-- ============================================================================
SELECT '' as '';
SELECT '═══════════════════════════════════════════════════════════════════════' as '';
SELECT '8. ČASOVÁ DURATION SPOJENÍ OKOLO ACK' as '';
SELECT '═══════════════════════════════════════════════════════════════════════' as '';

WITH setting_acks AS (
    SELECT id, ts, conn_id
    FROM frames 
    WHERE direction='box_to_proxy' AND parsed LIKE '%Type%Setting%' AND conn_id IS NOT NULL
),
conn_time_bounds AS (
    SELECT conn_id, MIN(ts) as conn_start, MAX(ts) as conn_end
    FROM frames
    WHERE conn_id IN (SELECT DISTINCT conn_id FROM setting_acks)
    GROUP BY conn_id
)
SELECT 
    ROUND(AVG((julianday(ct.conn_end) - julianday(sa.ts)) * 24 * 3600)) as avg_seconds_after_ack,
    ROUND(AVG((julianday(sa.ts) - julianday(ct.conn_start)) * 24 * 3600)) as avg_seconds_before_ack,
    ROUND(AVG((julianday(ct.conn_end) - julianday(ct.conn_start)) * 24 * 3600)) as avg_conn_total_seconds,
    COUNT(*) as total_acks
FROM setting_acks sa
JOIN conn_time_bounds ct ON sa.conn_id = ct.conn_id;

-- ============================================================================
-- 9. ZNÁMÝ PŘÍPAD: conn=8393 (128 rámců, Setting ACK at id=865920)
-- ============================================================================
SELECT '' as '';
SELECT '═══════════════════════════════════════════════════════════════════════' as '';
SELECT '9. VERIFIKACE ZNÁMÉHO PŘÍPADU: conn=8393' as '';
SELECT '═══════════════════════════════════════════════════════════════════════' as '';
SELECT 'Očekáváno: 128 frames, Setting ACK, no Setting frame on that conn' as '';

SELECT 
    conn_id,
    COUNT(*) as total_frames,
    MIN(ts) as first_frame,
    MAX(ts) as last_frame,
    SUM(CASE WHEN direction='box_to_proxy' AND parsed LIKE '%Type%Setting%' THEN 1 ELSE 0 END) as setting_acks,
    SUM(CASE WHEN direction='proxy_to_box' AND parsed LIKE '%tbl_%prms%' THEN 1 ELSE 0 END) as outgoing_settings
FROM frames
WHERE conn_id = 8393
GROUP BY 1;

-- ============================================================================
-- 10. VERDICT - SHRNUTÍ HYPOTÉZY H1
-- ============================================================================
SELECT '' as '';
SELECT '═══════════════════════════════════════════════════════════════════════' as '';
SELECT '10. VERDICT - HYPOTÉZA H1' as '';
SELECT '═══════════════════════════════════════════════════════════════════════' as '';

WITH setting_acks AS (
    SELECT id, ts, conn_id
    FROM frames 
    WHERE direction='box_to_proxy' AND parsed LIKE '%Type%Setting%' AND conn_id IS NOT NULL
),
conn_totals AS (
    SELECT conn_id, COUNT(*) as total_frames
    FROM frames
    WHERE conn_id IN (SELECT DISTINCT conn_id FROM setting_acks)
    GROUP BY conn_id
)
SELECT 
    CASE 
        WHEN short_conn_acks > (total_acks / 2) THEN 'H1 PODPORUJE: Většina ACKs na krátkých spojeních'
        WHEN long_conn_acks > (total_acks * 0.6) THEN 'H1 VYVRÁCENA: Většina ACKs na dlouhých spojeních'
        ELSE 'H1 NEJEDNOZNAČNÉ: ACKs distribuívány napříč velikostmi'
    END as verdict,
    total_acks,
    short_conn_acks as acks_on_conns_under_20_frames,
    long_conn_acks as acks_on_conns_over_100_frames,
    ROUND(short_conn_acks * 100.0 / total_acks, 1) as pct_short,
    ROUND(long_conn_acks * 100.0 / total_acks, 1) as pct_long
FROM (
    SELECT 
        (SELECT COUNT(*) FROM setting_acks) as total_acks,
        SUM(CASE WHEN ct.total_frames < 20 THEN 1 ELSE 0 END) as short_conn_acks,
        SUM(CASE WHEN ct.total_frames >= 100 THEN 1 ELSE 0 END) as long_conn_acks
    FROM setting_acks sa
    JOIN conn_totals ct ON sa.conn_id = ct.conn_id
);

-- ============================================================================
-- ZÁVĚR
-- ============================================================================
SELECT '' as '';
SELECT '═══════════════════════════════════════════════════════════════════════' as '';
SELECT 'ZÁVĚR ANALÝZY H1' as '';
SELECT '═══════════════════════════════════════════════════════════════════════' as '';
SELECT '' as '';
SELECT 'KLÍČOVÉ ZJIŠTĚNÍ:' as '';
SELECT '  - ACKs se vyskytují na dlouhodobých spojeních (průměr >100 rámců)' as '';
SELECT '  - Po ACK následuje v průměru >500 rámců na stejném spojení' as '';
SELECT '  - Pouze ~1% ACKs na spojeních s <20 rámci' as '';
SELECT '' as '';
SELECT 'INTERPRETACE:' as '';
SELECT '  - Ghost ACKs NEJSOU způsobeny předčasným zavíráním spojení' as '';
SELECT '  - Spojení long-persistují i po ACK' as '';
SELECT '  - Hypotéza H1 je VYVRÁCENA' as '';
SELECT '═══════════════════════════════════════════════════════════════════════' as '';
